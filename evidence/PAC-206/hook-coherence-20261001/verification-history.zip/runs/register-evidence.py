import csv,json,sys
from pathlib import Path
csv.field_size_limit(16*1024*1024)
sys.path.insert(0,str(Path('.PACER/tool-runtime/pacer-0.5-c962631/plugins/pacer/src').resolve()))
from pacer_mcp.service import Service
s=Service(Path.cwd());c=s.context('PAC-206',max_bytes=1000000);snap=s.store.load();ix={r['ID']:r for rows in snap.tables.values() for r in rows}
base='evidence/PAC-206/hook-coherence-20261001/'
assets=[
('OVR-1874','report.md','Hook loading, cover paths and impact repair evidence with explicit remaining defects','OVR-1063;OVR-1758;OVR-1865;OVR-1067;OVR-1768;OVR-1827;OVR-1818;OVR-1857;OVR-1790'),
('OVR-1875','gameplay.mp4','Current 24-second production-camera boxing capture','OVR-1865;OVR-1031'),
('OVR-1876','inspection.mp4','Labelled diagnostic side capture of the same exchange','OVR-1865;OVR-1031'),
('OVR-1877','hook-before.mp4','Original abrupt hook replay from shared tick2390 checkpoint','OVR-1865;OVR-1884'),
('OVR-1878','hook-after.mp4','Repaired hook from the same checkpoint and 180 inputs','OVR-1865;OVR-1884'),
('OVR-1879','hook-inspection-before.png','Dense original hook diagnostic sheet','OVR-1865;OVR-1884'),
('OVR-1880','hook-inspection-after.png','Dense repaired hook diagnostic sheet','OVR-1865;OVR-1884'),
('OVR-1881','source-hashes.json','141 source-file identities bound to current GPU captures','OVR-1865;OVR-1063;OVR-1758;OVR-1827'),
('OVR-1882','verification-history.zip','Preserved source, failed approaches, invalid fixture logs, corrected checks and saved failures','OVR-1865;OVR-1063;OVR-1758;OVR-1827'),
('OVR-1883','gameplay-frame.png','Current production chase view at six simulated seconds','OVR-1865;OVR-1031'),
('OVR-1884','hook-checkpoint.json','Original tick2390 fight state before the SLUGGER loading defect','OVR-1865')]
assert all(id not in ix and Path(base+file).is_file() for id,file,_,_ in assets)
ops=[]
for id,file,purpose,requires in assets:
 ops.append({'op':'add','register':'overlord','row':{'ID':id,'AssetType':'FILE','Path':base+file,'Purpose':purpose,'Requires':requires,'OGMRefs':'OGM-025','PACRefs':'PAC-206','NDLRefs':'NDL-013','Tags':'#boxing #combat #playtest','Notes':'2026-10-01: Bounded diagnostic evidence. Foundation NOT_ACCEPTED; fast guard/return transitions remain.'}})
 ops.append({'op':'link','id':'NDL-013','field':'TargetOVR','target':id})
ops.append({'op':'set','id':'NDL-013','fields':{'NewAssets':';'.join(dict.fromkeys(ix['NDL-013']['NewAssets'].split(';')+[base+file for _,file,_,_ in assets]))}})
for target in ['OVR-906','OVR-1758']:ops.append({'op':'link','id':'OVR-1865','field':'Requires','target':target})
ops.append({'op':'set','id':'OVR-1865','fields':{'Imports':';'.join(dict.fromkeys(filter(None,ix['OVR-1865']['Imports'].split(';')+['res://sim/punch_contact.gd','core._head_world'])))}})
def note(id,text,field='Notes'):ops.append({'op':'append','id':id,'field':field,'text':'2026-10-01: '+text})
for id in ['OVR-1063','OVR-1072']:
 note(id,'Loading clearance follows actual arm extension, low cover rotates with ribs, and native neutral-to-cover travel follows a shoulder-centred arc rather than a collapsing straight chord. Original guard and punch clocks retained. Shared-checkpoint hook replay preserved; broad guard/return motion remains unfinished. Evidence/PAC-206/hook-coherence-20261001/report.md.')
for id in ['OVR-1758','OVR-1765']:
 note(id,'Swept impact preserves both evaluated arm goals/poles and writes both final elbow/knee histories. Prevents re-solving the covering arm from stale authored goals. Contact443/443; every-impact repeat solve checked. No foundation acceptance.')
note('OVR-1865','Checks repeated constraints at every resolved impact; exports original SLUGGER checkpoint and same-clock probe; captures 180-tick shared-checkpoint replay or24sec production exchange. Diagnostic side view remains labelled.')
note('OVR-1827','Corrected invalid contact-stop fixture: supply kind=hit,time=1,point; verify finish completed by matching saved contact and check both elbows. Prior278/278 verdicts were invalid because3908 script errors left the old pose unchanged. Corrected current278/278 has zero script errors. Original logs retained.')
note('OVR-1866','Correction appended to historical report: prior stance278/278 withdrawn due3908 script errors from malformed finish fixture. New hook-coherence report contains corrected evidence. Historical claims/logs preserved, foundation remains NOT_ACCEPTED.')
ops.append({'op':'link','id':'OVR-1866','field':'Requires','target':'OVR-1874'})
note('PAC-206','Continued core repairs: actual arm-phase clearance, ribcage-relative low cover, shoulder-centred guard arc, and consistent impact poses/history for both arms. Evidence/PAC-206/hook-coherence-20261001/report.md preserves original/repaired hook replay and current gameplay. Current sustained exchanges64/64 with1336 contacts; motion342/342, contact443/443, corrected stance278/278, head motion153/153, attachment128/128, Northern Rising70/70; logs scanned for script errors. Motion driver retains an intermittent two-ObjectDB exit warning. DOING/NOT_ACCEPTED retained: matrix0.124244m covering-elbow peak at ordinary SLUGGER opponent tick363 and0.167403m ordinary OUTBOXER wrist peak tick573 remain for motion review.')
note('PAC-206','Clearance-only and impact-history-only approaches left rotating-cover defects. A100ms guard transition was tested, failed the SLIP_R physical-guard counter check341/342, and was removed; original50ms clock retained with geometric guard-arc correction. Stance278/278 had falsely passed despite3908 script errors in old incomplete contact fixture; corrected fixture now proves finish completed and checks both arms. Direct NextAction set was rejected atomically by PACER; no rows were committed from that batch. All failures preserved.', 'PreviousAttempts')
note('PAC-206','Guard translation alone is insufficient during ribcage turn; low cover needs chest orientation. Cover should travel around its shoulder instead of collapsing reach along a Cartesian chord. CCD finish must retain non-striking limbs/history. Always scan engine logs: an aborted GDScript call can leave a pose unchanged and let a geometric assertion falsely pass. Compare connected replays from a preceding shared checkpoint.', 'LearningNotes')
note('PAC-206','Next work remains core motion: inspect the ordinary SLUGGER covering elbow at tick363 and OUTBOXER wrist at tick573, distinguish intended strike speed from solver jumps, and verify fixes in actual exchanges. Do not advance peripheral systems or promote foundation status.')
note('OGM-025','Source repairs and corrected stance verification recorded in evidence/PAC-206/hook-coherence-20261001/report.md. Prior stance fixture green withdrawn; corrected run has zero script errors. PACED_REQUIREMENT/NOT_ACCEPTED retained with empty AcceptanceEvidence. Fast guard/return transitions and complete boxing feel/visual qualification remain open.')
r=s.apply(ops,actor='codex',revision=snap.revision,onboarding=s.authority()['onboarding'],context=c['receipt'])
print(json.dumps({'revision':r.get('revision'),'validation':s.validate()},default=str))
