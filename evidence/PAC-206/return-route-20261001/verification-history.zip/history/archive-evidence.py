from pathlib import Path
import hashlib,json,zipfile

root=Path.cwd();scratch=root/'.PACER/return-route-20261001';out=root/'evidence/PAC-206/return-route-20261001'
expected=json.loads((out/'source-hashes.json').read_text())
assert all(hashlib.sha256((root/'engine/greybox'/p).read_bytes()).hexdigest()==v for p,v in expected.items())
entries={}
for p in expected:entries['current-source/'+p]=root/'engine/greybox'/p
variants=['baseline-project','phase-return-candidate','world-return-candidate']
for phase in variants:
    for name in ['presentation/boxing_motion.gd','sim/punch_contact.gd','sim/core.gd','tools/drive_boxing_exchange.gd','tools/drive_stance_coherence.gd']:
        
        if (scratch/phase/name).is_file():entries[phase+'/'+name]=scratch/phase/name
for f in scratch.rglob('*'):
    if not f.is_file():continue
    rel=f.relative_to(scratch)
    if '.godot' in rel.parts or rel.parts[0] in variants:continue
    if f.suffix.lower() in ['.log','.json','.gd','.py','.md']:
        entries['history/'+str(rel).replace('\\','/')]=f
for phase in scratch.glob('capture-*'):
    folder=next(phase.rglob('chase-0000.png'),None)
    if folder is None:continue
    for camera in ['chase','inspection']:
        for frame in [0,16,19,20,23,24,25,60,120,179,180,360,600,719]:
            f=folder.parent/f'{camera}-{frame:04}.png'
            if f.exists():entries['selected-frames/'+phase.name+'/'+f.name]=f
archive=out/'verification-history.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,f in sorted(entries.items()):z.write(f,name)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
meta={'entries':len(entries),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'source_files':len(expected),'crc_verified':True}
(scratch/'archive-verification.json').write_text(json.dumps(meta,indent=2))
print(json.dumps(meta))
