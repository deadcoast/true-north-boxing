from pathlib import Path
import hashlib, json, shutil, subprocess
from PIL import Image, ImageDraw, ImageFont

root=Path.cwd(); scratch=root/'.PACER/guard-transition-20261001'; out=root/'evidence/PAC-206/guard-transition-20261001'
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',19)
def frames(name):
    return next((scratch/name).rglob('chase-0000.png')).parent
def encode(name, folder, camera, fps, count):
    assert len(list(folder.glob(camera+'-*.png')))==count,(name,folder)
    args=['ffmpeg','-hide_banner','-loglevel','error','-y','-framerate',str(fps),'-i',str(folder/(camera+'-%04d.png'))]
    args+=['-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart',str(out/name)]
    subprocess.run(args,check=True)
    meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_entries','stream=nb_read_frames,width,height,r_frame_rate,duration','-of','json',str(out/name)]))
    assert int(meta['streams'][0]['nb_read_frames'])==count
    subprocess.run(['ffmpeg','-v','error','-i',str(out/name),'-f','null','-'],check=True)
    return meta

pairs={
 'guard':('gpu-before','capture-complete-guard',4120,[34,35,36,37,38,39],'Resting-cover threshold / immediate guard stroke'),
 'hook':('gpu-hook-before','capture-complete-hook',160,[24,26,28,30,32,34],'Cartesian bulge / bounded curved delivery'),
 'upper':('capture-before-upper','capture-complete-upper',1250,[45,46,47,48,49,50],'Intermediate live-guard steering / committed launch'),
 'straight-transfer':('capture-before-straight-transfer','capture-complete-straight-transfer',1200,[18,19,20,21,22,23],'Intermediate home retraction / captured launch arm'),
}
metadata={}
for stem,(before,after,start,indices,title) in pairs.items():
    sheet=Image.new('RGB',(2304,630),'#17191c');draw=ImageDraw.Draw(sheet)
    draw.text((14,8),title+' | diagnostic side view, identical saved input sequence',font=font,fill='white')
    for row,phase in enumerate([before,after]):
        folder=frames(phase)
        metadata[stem+('-before.mp4' if row==0 else '-after.mp4')]=encode(stem+('-before.mp4' if row==0 else '-after.mp4'),folder,'inspection',120,180)
        for col,n in enumerate(indices):
            x=col*384;y=42+row*290
            draw.text((x+8,y),('BEFORE' if row==0 else 'AFTER')+f' - tick {start+n+1}',font=font,fill='white')
            im=Image.open(folder/f'inspection-{n:04}.png').crop((256,170,1024,650)).resize((384,240),Image.Resampling.LANCZOS)
            sheet.paste(im,(x,y+27))
    sheet.save(out/(stem+'-comparison.png'))
folder=frames('capture-complete-gameplay')
metadata['gameplay.mp4']=encode('gameplay.mp4',folder,'chase',30,720)
metadata['inspection.mp4']=encode('inspection.mp4',folder,'inspection',30,720)
shutil.copy2(folder/'chase-0180.png',out/'gameplay-frame.png')
sheet=Image.new('RGB',(1920,1012),'#17191c');draw=ImageDraw.Draw(sheet)
for i,n in enumerate([0,60,120,180,240,300,360,420,480,540,600,660]):
    x=i%4*480;y=i//4*337
    draw.text((x+8,y+4),f'Diagnostic side view - {n/30:.1f} s',font=font,fill='white')
    im=Image.open(folder/f'inspection-{n:04}.png').crop((160,200,1120,720)).resize((480,260),Image.Resampling.LANCZOS)
    sheet.paste(im,(x,y+30))
sheet.save(out/'inspection-sheet.png')
(scratch/'video-verification.json').write_text(json.dumps(metadata,indent=2))
expected=json.loads((scratch/'complete-source-hashes.json').read_text())
changed=[p for p,v in expected.items() if hashlib.sha256((root/'engine/greybox'/p).read_bytes()).hexdigest()!=v]
assert not changed,changed
print('Verified',len(metadata),'videos; current source matches',len(expected),'capture identities.')
