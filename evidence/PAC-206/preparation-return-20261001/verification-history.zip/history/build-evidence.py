from pathlib import Path
import hashlib, json, shutil, subprocess
from PIL import Image, ImageDraw, ImageFont

root=Path.cwd(); scratch=root/'.PACER/preparation-return-20261001'; out=root/'evidence/PAC-206/preparation-return-20261001'
out.mkdir(parents=True,exist_ok=True)
font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',19)

def frames(name):
    film=json.loads(next((scratch/name).rglob('film.json')).read_text())
    assert film['render_read_only'],name
    return next((scratch/name).rglob('chase-0000.png')).parent

def encode(name, folder, camera, fps, count):
    assert len(list(folder.glob(camera+'-*.png')))==count,(name,folder)
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-framerate',str(fps),'-i',str(folder/(camera+'-%04d.png')),
        '-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart',str(out/name)],check=True)
    meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_entries','stream=nb_read_frames,width,height,r_frame_rate,duration','-of','json',str(out/name)]))
    assert int(meta['streams'][0]['nb_read_frames'])==count
    subprocess.run(['ffmpeg','-v','error','-i',str(out/name),'-f','null','-'],check=True)
    return meta

pairs={
 'prepared':('capture-prepared-before','capture-coherent-prepared',5095,[21,22,23,24,25,26],'Tell into committed physical punch lane'),
 'cover':('capture-cover-before','capture-coherent-cover',720,[16,17,18,19,20,21],'Opposite hand folds with the solved shoulder'),
}
metadata={}
for stem,(before,after,start,indices,title) in pairs.items():
    sheet=Image.new('RGB',(2304,630),'#17191c');draw=ImageDraw.Draw(sheet)
    draw.text((14,8),title+' | diagnostic side view, identical saved input sequence',font=font,fill='white')
    for row,phase in enumerate([before,after]):
        folder=frames(phase)
        name=stem+('-before.mp4' if row==0 else '-after.mp4')
        metadata[name]=encode(name,folder,'inspection',120,180)
        for col,n in enumerate(indices):
            x=col*384;y=42+row*290
            draw.text((x+8,y),('BEFORE' if row==0 else 'AFTER')+f' - tick {start+n+1}',font=font,fill='white')
            im=Image.open(folder/f'inspection-{n:04}.png').crop((256,170,1024,650)).resize((384,240),Image.Resampling.LANCZOS)
            sheet.paste(im,(x,y+27))
    sheet.save(out/(stem+'-comparison.png'))

folder=frames('capture-coherent-gameplay')
metadata['gameplay.mp4']=encode('gameplay.mp4',folder,'chase',30,720)
metadata['inspection.mp4']=encode('inspection.mp4',folder,'inspection',30,720)
shutil.copy2(folder/'chase-0180.png',out/'gameplay-frame.png')
sheet=Image.new('RGB',(1920,1012),'#17191c');draw=ImageDraw.Draw(sheet)
for i,n in enumerate(range(0,720,60)):
    x=i%4*480;y=i//4*337
    draw.text((x+8,y+4),f'Diagnostic side view - {n/30:.1f} s',font=font,fill='white')
    im=Image.open(folder/f'inspection-{n:04}.png').crop((160,170,1120,650)).resize((480,240),Image.Resampling.LANCZOS)
    sheet.paste(im,(x,y+30))
sheet.save(out/'inspection-sheet.png')
for name in ['prepared-checkpoint.json','cover-checkpoint.json']:
    shutil.copy2(scratch/name,out/name)
shutil.copy2(scratch/'coherent-source-hashes.json',out/'source-hashes.json')
(scratch/'video-verification.json').write_text(json.dumps(metadata,indent=2))
expected=json.loads((out/'source-hashes.json').read_text())
changed=[p for p,v in expected.items() if hashlib.sha256((root/'engine/greybox'/p).read_bytes()).hexdigest()!=v]
assert not changed,changed
print('Verified',len(metadata),'videos; current source matches',len(expected),'capture identities.')
