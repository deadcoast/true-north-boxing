extends SceneTree
const Tests=preload("res://sim/tests.gd")
const Motion=preload("res://presentation/boxing_motion.gd")
func _initialize():
	var tests=Tests.new()
	var saved=JSON.parse_string(FileAccess.get_file_as_string(OS.get_environment("BOXING_WORST")))
	var s=tests.make_sim(0,719);s.restore(saved["snapshot"])
	var f=s.B if saved["who"]=="B" else s.P
	var rig=f["boxing"]["rig"];var before=f["boxing"]["previous_rig"]
	var i=int(saved["detail"]["hand"])
	print("ACTION ",JSON.stringify(f["boxing"]["action"]))
	for pair in [["before",before],["after",rig]]:
		var r=pair[1];var shoulder=r["shoulders"][i];var hand=r["wrists"][i];var axis=(hand-shoulder).normalized()
		var pole=r["arm_poles"][i];var prior=r["support_elbows"][i]-shoulder;prior-=axis*prior.dot(axis)
		var wanted=pole-axis*pole.dot(axis)
		pole=prior.normalized().slerp(wanted.normalized(),minf(0.4,0.18/maxf(prior.angle_to(wanted),0.0001)))
		print(pair[0]," requested_pole ",pole," solved ",r["elbows"][i]-shoulder)
		var arm=Motion.joint(shoulder,hand,pole,Motion.UPPER_ARM,Motion.FOREARM)
		print("raw ",arm," gap ",Motion._arm_gap(r,arm,i)," final ",r["elbows"][i]," head ",r["head"])
		for n in range(-5,6):
			var angle=n*PI/24.0
			var candidate=Motion.joint(shoulder,hand,pole.rotated(axis,angle),Motion.UPPER_ARM,Motion.FOREARM)
			print("plane ",n," gap ",Motion._arm_gap(r,candidate,i)," elbow ",candidate["joint"])
	quit()
