extends SceneTree
## Sustained native exchanges. Measures the actual shared collision/render rig.
const Tests := preload("res://sim/tests.gd")
const Space := preload("res://presentation/rig_space.gd")
const Techniques := preload("res://sim/boxing_techniques.gd")
var tests := Tests.new()
var samples := []
var worst := {}

func _initialize() -> void: run.call_deferred()

func cylinder_gap(point: Vector3, bottom: Vector3, top: Vector3) -> float:
	var axis := top-bottom
	var up := axis.normalized()
	var relative := point-(bottom+top)*0.5
	var height := relative.dot(up)
	var d := Vector2((relative-up*height).length()-Space.BODY_RADIUS,absf(height)-axis.length()*0.5)
	return Vector2(maxf(d.x,0),maxf(d.y,0)).length()+minf(maxf(d.x,d.y),0)

func record(s, label: String, who: String, key: String, value: float, peak: Dictionary, detail := {}) -> void:
	peak[key]=maxf(peak.get(key,0),value)
	if value > float(worst.get(key,{}).get("value",0)):
		worst[key]={"case":label,"who":who,"tick":s.tick,"value":value,"detail":detail,"snapshot":s.snapshot()}

func measure(s, label: String, who: String, peak: Dictionary, prior: Dictionary) -> void:
	var f: Dictionary=s.P if who=="P" else s.B
	if not f.has("boxing"):return
	var rig: Dictionary=f["boxing"]["rig"]
	var top: Vector3=(rig["shoulders"][0]+rig["shoulders"][1])*0.5
	var bottom: Vector3=rig["pelvis"]+Vector3.UP*0.04
	for hand in 2:
		var elbow: Vector3=rig["elbows"][hand];var wrist: Vector3=rig["wrists"][hand]
		var nearest:=Geometry3D.get_closest_point_to_segment(rig["head"],elbow,wrist)
		record(s,label,who,"forearm_head_penetration_m",Space.HEAD_RADIUS+0.085-nearest.distance_to(rig["head"]),peak,{"hand":hand})
		record(s,label,who,"glove_torso_penetration_m",Space.GLOVE_RADIUS-cylinder_gap(wrist,bottom,top),peak,{"hand":hand})
		var penetration:=0.0
		for n in 17:penetration=maxf(penetration,0.085-cylinder_gap(elbow.lerp(wrist,n/16.0),bottom,top))
		record(s,label,who,"forearm_torso_penetration_m",penetration,peak,{"hand":hand})
	if prior.has(who):
		var last: Dictionary=prior[who]
		for key in ["head","pelvis"]:
			record(s,label,who,key+"_step_m",Vector3(rig[key]).distance_to(last[key]),peak)
		for key in ["elbows","wrists","knees"]:
			for hand in 2:record(s,label,who,key+"_step_m",Vector3(rig[key][hand]).distance_to(last[key][hand]),peak,{"hand":hand})
	prior[who]=rig.duplicate(true)

func command(tick: int, s) -> Dictionary:
	var cycle:=tick%360
	var axis:=Vector2.ZERO
	if cycle<105:axis=Vector2(sin(cycle/105.0*TAU)*0.65,-sin(cycle/105.0*PI)*0.65)
	var input:={"body_axis":axis,"block":cycle>=150 and cycle<300,"body":cycle>=210 and cycle<270}
	var rows:=["L_STRAIGHT","R_STRAIGHT","L_HOOK","R_UPPERCUT","L_UPPERCUT","R_HOOK"]
	if cycle>=110 and cycle<278 and (cycle-110)%28==0:input["punch"]=rows[(cycle-110)/28]
	if cycle==310:
		var distance: float=Vector2(s.P["pos"]).distance_to(s.B["pos"])
		input["pocket_step"]=Vector2(0.55,-0.7) if distance>1.65 else Vector2(-0.55,0.65)
	if s.mode=="EIGHT":input["rise"]=tick%2==0
	if s.mode in ["CARD","CORNER"]:input["corner"]=1
	return input

func run() -> void:
	for style in ["BOXERPUNCHER","OUTBOXER","SWARMER","SLUGGER"]:
		for learned in [false,true]:
			var s=tests.make_sim(0,719)
			tests.place(s,1.5)
			for f in [s.P,s.B]:
				f["style"]=style;f["stance"]="southpaw" if learned else "orthodox";f["boxing_training"]={}
				if learned:Techniques.equip(f,{"name":"RORY"})
			var peak:={};var prior:={};var contacts:={};var modes:={};var timings:=[]
			var label:="%s learned=%s"%[style,learned]
			for tick in 10800:
				s.events.clear()
				var started:=Time.get_ticks_usec();s.step(command(tick,s));timings.append(Time.get_ticks_usec()-started)
				modes[s.mode]=int(modes.get(s.mode,0))+1
				if s.mode=="FIGHT":
					for who in ["P","B"]:measure(s,label,who,peak,prior)
				else:prior.clear()
				for e in s.events:
					if e.get("kind")=="boxing_contact":
						var kind:=str(e["by"])+" "+str(e["contact"]["kind"])
						contacts[kind]=int(contacts.get(kind,0))+1
				if s.mode in ["RESULT","END","COMPLETE"]:break
			timings.sort()
			var result:={"case":label,"peak":peak,"contacts":contacts,"modes":modes,"step_p95_us":timings[int(timings.size()*0.95)]}
			samples.append(result);print(JSON.stringify(result))
	for key in worst:FileAccess.open("user://worst-"+key+".json",FileAccess.WRITE).store_string(JSON.stringify(worst[key],"\t"))
	FileAccess.open("user://exchange.json",FileAccess.WRITE).store_string(JSON.stringify(samples,"\t"))
	quit()
