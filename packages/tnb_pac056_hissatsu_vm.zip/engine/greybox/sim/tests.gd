extends RefCounted
const TNBSim := preload("res://sim/core.gd")
const TNBClock := preload("res://sim/clock.gd")
# Executable proofs for NP_14 (C1-C7). Drives TNBSim directly: no Nodes, no
# frames, no wall clock. Every assertion names the claim it serves.
#   godot --headless --path engine/greybox -- smoke boss=N
#   godot --headless --path engine/greybox -- determinism
#   godot --headless --path engine/greybox -- geometry
# Exit code 0 = GREEN. Anything else = a claim in NP_14 is falsified.

var results: Array = []
var content: Dictionary

func _sr(name: String, ok: bool, detail: String = "") -> void:
	results.append([name, ok, detail])
	print("  [%s]  %-46s %s" % [" OK " if ok else "FAIL", name, detail])

func _verdict(label: String) -> int:
	var fails := 0
	for r in results:
		if not r[1]: fails += 1
	print("%s VERDICT :: %s (%d/%d)" % [label, "GREEN" if fails == 0 else "RED", results.size() - fails, results.size()])
	return 0 if fails == 0 else 1

func make_sim(boss_idx: int, seed_v: int, lineup: Array = TNBSim.LINEUP_MILLBROOK) -> TNBSim:
	if content.is_empty(): content = TNBSim.load_content()
	var s := TNBSim.new()
	s.setup(content["tuning"], content["patterns"], TNBSim.BOSSES, lineup, boss_idx, seed_v, content.get("library", {}))
	return s

func play_clinch(s: TNBSim, mode: String, want_reset: bool = false) -> void:
	# mode: sides (LS on the cue's side) | wrong (opposite side) | enter (button parity) | mash | none
	var n := 0
	while s.clinch.size() > 0 and n < 2000:
		var inp := {"body": want_reset}
		var i: int = s.clinch["i"]
		if i < s.clinch["cues"].size():
			var c: int = s.clinch["cues"][i]; var w: int = s.clinch["windows"][i]; var t: int = int(s.clinch["t"]) + 1
			var in_win := absi(t - c) <= w
			var side: String = s.clinch["sides"][i]
			match mode:
				"sides": if in_win: inp["move"] = Vector2(-1, 0) if side == "L" else Vector2(1, 0)
				"wrong": if in_win: inp["move"] = Vector2(1, 0) if side == "L" else Vector2(-1, 0)
				"enter": if in_win: inp["rise"] = true
				"mash": inp["move"] = Vector2(-1, 0) if (n / 10) % 2 == 0 else Vector2(1, 0)
		s.step(inp); n += 1

func resolve_cast(s: TNBSim, max_ticks: int = 600) -> void:
	var n := 0
	while s.cast.size() > 0 and n < max_ticks: s.step({}); n += 1

func with_move(boss_idx: int, seed_v: int, move: String) -> TNBSim:
	var lu: Array = TNBSim.LINEUP_MILLBROOK.duplicate(true); lu[0]["hissatsu"] = move
	var t := make_sim(boss_idx, seed_v, lu); quiet(t); place(t, 1.4); t.tension = 100.0
	t.B["comp"] = t.B["comp_max"]; t.P["comp"] = t.P["comp_max"]
	return t

func cast_player(s: TNBSim) -> bool:
	# arm + the move's family motion (or the WALL hold), then run the cinematic to its resolve
	var mv: Dictionary = s.player_move()
	thaw(s); s.P["busy_t"] = 0; s.P["cmd"] = {}; s.events.clear()
	if str(mv["family"]) == "WALL":
		run_ticks(s, TNBSim.ms(400) + 1, {"lb": true, "block": true})
	else:
		s.step({"punch": TNBSim.FAMILY_ROW[str(mv["family"])], "lb": true})
	if s.cast.is_empty(): return false
	return true

func boss_desperation(s: TNBSim) -> bool:
	# push the boss under his desperation trigger and let one agent tick arm it
	thaw(s); s.bstate = "IDLE"; s.btimer = 1 << 30; s.B["comp"] = s.B["comp_max"] * 0.15; s.bsurvival_used = true; s.events.clear()
	s.step({})
	return s.cast.size() > 0 and s.cast["who"] == "B"

func gauge_dmg(s: TNBSim) -> float:
	var total := 0.0
	for e in s.events:
		if e["kind"] == "gauge": total += float(e["dmg"])
	return total

func hit_dmg(s: TNBSim, on: String) -> float:
	var total := 0.0
	for e in s.events:
		if e["kind"] == "hit" and e["on"] == on: total += float(e["dmg"])
	return total

func sensor_count(s: TNBSim, name: String) -> int:
	return count_events(s.events, "sensor", {"name": name})

func quiet(s: TNBSim) -> void:
	# sensors keep firing as events; bait/punish hooks stay silent; boss frozen; hitstop drained
	s.hooks_enabled = false; freeze_boss(s); thaw(s); s.events.clear()

func run(mode: String, boss_idx: int) -> int:
	match mode:
		"smoke": return smoke(boss_idx)
		"determinism": return determinism()
		"geometry": return geometry()
	print("unknown test mode: " + mode)
	return 2

# ---------------------------------------------------------------- helpers ----
func freeze_boss(s: TNBSim) -> void:
	s.bstate = "IDLE"; s.btimer = 1 << 30; s.bqueue = []; s.bpending = {}
	s.clinch = {}; s.clinch_t = 0; s.hands_down_t = 0
	if s.P["busy_t"] > 60: s.P["busy_t"] = 0

func place(s: TNBSim, spacing: float = 1.6) -> void:
	s.P["pos"] = Vector2(0.0, spacing * 0.5); s.B["pos"] = Vector2(0.0, -spacing * 0.5)

func clear_defense(F: Dictionary) -> void:
	F["dodge"] = ""; F["dodge_t"] = 0; F["dodge_at"] = 0; F["dodge_plan"] = []
	F["blocking"] = false; F["block_t"] = 0

func run_ticks(s: TNBSim, n: int, inp: Dictionary = {}) -> void:
	for i in n: s.step(inp)

func thaw(s: TNBSim) -> void:
	while s.freeze_t > 0: s.step({})

func land(s: TNBSim, max_ticks: int = 400) -> void:
	# advance until the player's queued/pending punch resolves (boss frozen by caller)
	var n := 0
	while (s.P["cmd"].size() > 0 or s.P["pending"].size() > 0) and n < max_ticks:
		s.step({}); n += 1

func throw_clean(s: TNBSim, row: String, extra: Dictionary = {}) -> void:
	# throw with the boss's read cancelled: isolates the effect under test from the RNG
	var inp := extra.duplicate(); inp["punch"] = row
	thaw(s)
	s.P["busy_t"] = 0; s.P["cmd"] = {}
	s.step(inp)
	clear_defense(s.B)
	land(s)

func boss_lands(s: TNBSim, row: String, mult: float = 1.0, body: bool = false) -> void:
	s.bpending = {"row": row, "mult": mult, "body": body}
	s._land_boss_punch(mult)

func count_events(evs: Array, kind: String, filt: Dictionary = {}) -> int:
	var n := 0
	for e in evs:
		if e["kind"] != kind: continue
		var ok := true
		for k in filt:
			if not e.has(k) or e[k] != filt[k]: ok = false
		if ok: n += 1
	return n

# ------------------------------------------------------------------ SMOKE ----
func smoke(boss_idx: int) -> int:
	var s := make_sim(boss_idx, 12345)
	print("SMOKE :: TNBSim core, boss=%s" % TNBSim.BOSSES[boss_idx])
	var gauge_boss: bool = s.wall["B"].size() > 0 and float(s.wall["B"].get("pts", 0.0)) > 0.0
	if gauge_boss:
		print("  (wall-gauge anchor: the gauge is stripped for the generic stages and tested on its own below)")
		s.wall["B"] = {}
	_sr("tuning + 24 patterns loaded", s.T.size() > 0 and s.patterns.size() == 24 and s.pattern.size() > 0)
	var vc := s.verb_coverage(s.patterns)
	_sr("action VM executes every verb the compiler emits (24 patterns)", vc["unknown"].is_empty(),
		"%d verbs known%s" % [vc["known"].size(), "" if vc["unknown"].is_empty() else "  UNKNOWN: " + JSON.stringify(vc["unknown"])])
	var pc := s.phase_coverage(s.patterns)
	print("  phase-trigger vocabulary: %d forms executable, %d not yet: %s" % [pc["known"].size(), pc["unknown"].size(), JSON.stringify(pc["unknown"])])
	_sr("dual opens FIGHT / R1 RORY", s.mode == "FIGHT" and s.pname() == "RORY")

	# ---- C3: input buffer ----
	freeze_boss(s); place(s); thaw(s)
	s.step({"punch": "L_STRAIGHT"})
	_sr("C3 free fighter executes on the same tick", s.P["pending"].size() > 0 and s.P["busy_t"] > 0,
		"busy=%d" % s.P["busy_t"])
	clear_defense(s.B)
	while s.P["busy_t"] > 3: s.step({})
	s.step({"punch": "R_STRAIGHT"})                    # issued 3 ticks before recovery ends
	var queued: bool = s.P["cmd"].size() > 0
	s.step({}); s.step({})                             # recovery reaches 0 on this tick
	_sr("C3 punch issued 3 ticks early fires on recovery-end tick",
		queued and s.P["pending"].get("row", "") == "R_STRAIGHT" and s.P["cmd"].is_empty())
	clear_defense(s.B); land(s)
	thaw(s); s.P["busy_t"] = 8; s.P["cmd"] = {}
	var tok0: int = s.tokens.size()
	s.step({"punch": "L_HOOK"})                        # issued 8 ticks early: outside the 6-tick life
	run_ticks(s, 10)
	_sr("C3 punch issued 8 ticks early expires unexecuted",
		s.P["cmd"].is_empty() and s.P["pending"].is_empty() and s.tokens.size() == tok0)

	# ---- C2: geometry sanity (the full table is -- geometry) ----
	place(s, 1.6); clear_defense(s.B)
	_sr("C2 straight reaches a neutral head at 1.6m", s.resolve_geometry(s.P, s.B, "R_STRAIGHT", false) == "HIT")
	place(s, 2.3)
	_sr("C2 straight falls short at 2.3m", s.resolve_geometry(s.P, s.B, "R_STRAIGHT", false) == "MISS_REACH")

	# ---- C7: tracker flags defense only ----
	place(s); freeze_boss(s); s.tokens = []; s.flags = {}
	for pu in s.pattern.get("punish", []): s.punish_cd[s._ev_key(str(pu["trigger"]))] = 1 << 30
	for i in 3: throw_clean(s, "L_STRAIGHT"); place(s)
	var w_before := JSON.stringify(s.pattern["select"]["weights"])
	var tells_before := ""
	for k in s.pattern["strings"]: tells_before += "%s:%d;" % [k, int(s.pattern["strings"][k]["tell"]["ms"])]
	freeze_boss(s)
	throw_clean(s, "L_STRAIGHT")                       # 4th jab: 2-gram count hits 3 -> flag
	var tier := s._flag_tier()
	_sr("tracker flags the repeated 2-gram", tier >= 1, "tier=%d" % tier)
	_sr("stamina drains on punches", s.P["stamina"] < 100.0, "%.1f" % s.P["stamina"])
	s.bstate = "IDLE"
	_sr("C7 flag raises the boss read probability", s.read_prob(tier, false, false, false) > s.read_prob(0, false, false, false),
		"%.2f -> %.2f" % [s.read_prob(0, false, false, false), s.read_prob(tier, false, false, false)])
	var tells_after := ""
	for k in s.pattern["strings"]: tells_after += "%s:%d;" % [k, int(s.pattern["strings"][k]["tell"]["ms"])]
	_sr("C7 boss offense byte-identical across the flag", JSON.stringify(s.pattern["select"]["weights"]) == w_before and tells_after == tells_before)
	_sr("C7 counter window lowers the read (fear is a number)", s.read_prob(0, true, false, false) < s.read_prob(0, false, false, false))

	# ---- interrupt ----
	place(s); freeze_boss(s); s.tokens = []; s.flags = {}
	s.bstate = "TELL"; s.bstring = s.pattern["strings"].keys()[0]; s.btimer = 1 << 30
	var comp_before: float = s.B["comp"]
	throw_clean(s, "R_STRAIGHT")
	_sr("interrupt breaks the tell", s.bstate != "TELL", "state=" + s.bstate)
	_sr("interrupt opens the flash window", s.P["flash_t"] > 0, "%d ticks" % s.P["flash_t"])
	_sr("interrupt pays tension", s.tension > 0.0, "%.1f" % s.tension)
	_sr("boss took damage", s.B["comp"] < comp_before)
	_sr("C5 hitstop is sim state (freeze ticks queued)", s.freeze_t > 0, "%d ticks" % s.freeze_t)
	var clk0: int = s.clock_t
	s.step({})
	_sr("C5 frozen tick advances no clock", s.clock_t == clk0)
	s.P["busy_t"] = 0; s.P["cmd"] = {}
	s.step({"punch": "L_HOOK"})                        # pressed during hitstop
	var buffered: bool = s.P["cmd"].size() > 0 or s.P["pending"].size() > 0
	thaw(s); s.step({})
	_sr("C3 a punch pressed during hitstop is buffered, not eaten", buffered and s.P["pending"].get("row", "") == "L_HOOK")
	clear_defense(s.B); land(s); s.P["flash_t"] = 0

	# ---- drops ----
	place(s); freeze_boss(s); s.tokens = []; s.flags = {}
	s.B["comp"] = 1.0
	var d0 := s.drops_p
	throw_clean(s, "R_UPPERCUT")
	_sr("DROP scored at composure<=0 (+1)", s.drops_p == d0 + 1 and s.score_p == 1, "%d-%d score %d-%d" % [s.drops_p, s.drops_b, s.score_p, s.score_b])
	_sr("post-drop composure resets to 50pct", absf(s.B["comp"] - s.B["comp_max"] * 0.5) < 1.0)
	thaw(s); place(s); s.B["comp"] = 1.0; s.P["flash_t"] = 60; s.tokens = []; s.flags = {}
	throw_clean(s, "R_STRAIGHT")
	_sr("FLASH DROP scores 2 (NP_01 s3)", s.drops_p == d0 + 2 and s.score_p == 3, "score %d-%d" % [s.score_p, s.score_b])
	thaw(s); place(s); s.B["comp"] = 1.0; s.P["flash_t"] = 0; s.tokens = []; s.flags = {}
	var seg0 := s.seg_idx
	throw_clean(s, "R_STRAIGHT")
	_sr("third drop = SEGMENT KO (+1 +3), segment ends, dual continues", s.B["drops"] == 3 and s.score_p == 7 and s.mode == "CORNER" and s.seg_idx == seg0,
		"score %d-%d mode=%s" % [s.score_p, s.score_b, s.mode])
	s.step({"corner": 1})
	s.new_dual(); freeze_boss(s)
	s.freeze_t = 0
	place(s); clear_defense(s.P); s.P["comp"] = 0.5
	var t0 := s.tension
	boss_lands(s, "R_HOOKERCUT")
	_sr("player drop enters the standing-eight", s.mode == "EIGHT" and s.eight.has("beats_left"))
	var beats := 0
	for b in 3:
		var guard := 0
		while s.mode == "EIGHT" and s.eight["timer_t"] > s.eight["window_t"] and guard < 400:
			s.step({}); guard += 1
		if s.mode != "EIGHT": break
		s.step({"rise": true}); s.step({"rise": false}); beats += 1
	_sr("standing-eight: three rise beats on the count get up",
		s.mode == "FIGHT" and s.P["comp"] > 0.0 and s.P["no_regen_t"] > 0 and beats == 3,
		"comp=%.1f halt=%d ticks" % [s.P["comp"], s.P["no_regen_t"]])
	_sr("crowd surge pays tension on the rise", s.tension > t0, "%.1f -> %.1f" % [t0, s.tension])

	# ---- guard ----
	place(s); freeze_boss(s); s.P["comp"] = s.P["comp_max"]; s.freeze_t = 0
	s.P["guard"] = 1.0; s.P["guard_open_t"] = 0
	run_ticks(s, 30, {"block": true})                  # held past the 150ms perfect window
	boss_lands(s, "R_STRAIGHT")
	_sr("guard break opens the fighter", s.P["guard_open_t"] > 0, "%d ticks" % s.P["guard_open_t"])
	run_ticks(s, s.P["guard_open_t"] + 2)
	_sr("guard refills after the break", s.P["guard"] >= float(s.T["guard"]["break_refill"]) - 1.0, "%.1f" % s.P["guard"])
	place(s); s.P["counter_t"] = 0; s.P["guard"] = s.P["guard_max"]; s.freeze_t = 0
	s.step({"block": true})                            # pressed this tick: inside the perfect window
	boss_lands(s, "R_STRAIGHT")
	_sr("perfect block inside 150ms opens a counter window", s.P["counter_t"] > 0, "%d ticks" % s.P["counter_t"])

	# ---- hissatsu: the motion is the spellbook ----
	place(s); freeze_boss(s); s.tokens = []; s.flags = {}; s.freeze_t = 0; thaw(s)
	s.tension = 100.0; s.B["comp"] = s.B["comp_max"]; s.P["counter_t"] = 0; s.events.clear()
	s.P["busy_t"] = 0; s.P["cmd"] = {}
	s.step({"punch": "R_HOOK", "lb": true})                 # wrong family for a HAYMAKER move: a normal hook
	var wrong_family: bool = s.cast.is_empty() and s.P["pending"].size() > 0 and s.tension == 100.0
	clear_defense(s.B); land(s); thaw(s)
	s.P["busy_t"] = 0; s.P["cmd"] = {}
	s.step({"punch": "R_HOOKERCUT", "lb": true})            # LB + haymaker flick = Aurora Borealis Breaker (T1, 35)
	var armed: bool = s.cast.size() > 0 and s.cast["who"] == "P" and str(s.cast["move"]["name"]) == "Aurora Borealis Breaker"
	_sr("hissatsu casts on LB + its family's motion; the wrong family throws the normal punch", wrong_family and armed)
	_sr("hissatsu costs its tier's Tension (T1 = 35), never the whole bar", absf(s.tension - 65.0) < 0.01, "%.0f left" % s.tension)
	_sr("the caster is locked for the cinematic windup (%d ticks)" % int(s.cast["total"]), s.P["busy_t"] >= int(s.cast["total"]))
	resolve_cast(s)
	_sr("ABB resolves from its record: x2.5 packet + ropes displacement + freeze state",
		count_events(s.events, "hit", {"hissatsu": true}) == 1 and count_events(s.events, "displace", {"toward": "ROPES"}) == 1 and s.states["B"].size() == 0 and s.states["P"].has("arena_freeze_vfx"))
	thaw(s); s.tension = 10.0; s.P["busy_t"] = 0; s.P["cmd"] = {}; s.events.clear()
	s.step({"punch": "R_HOOKERCUT", "lb": true})
	_sr("insufficient Tension: the motion executes as its normal punch (never a whiff-lockout)", s.cast.is_empty() and s.P["pending"].get("row", "") == "R_HOOKERCUT")
	clear_defense(s.B); land(s); s.freeze_t = 0

	# ---- boss agent live ----
	place(s); clear_defense(s.P); s.P["comp"] = s.P["comp_max"]; s.P["counter_t"] = 0
	s.bstate = "IDLE"; s.btimer = 1; s.events.clear()
	run_ticks(s, 480)
	var tells := count_events(s.events, "tell")
	var boss_actions := count_events(s.events, "boss_act")
	_sr("boss agent runs strings on its own (4s)", tells >= 1, "tells=%d state=%s string=%s" % [tells, s.bstate, s.bstring])
	_sr("action VM executes the selected strings", boss_actions >= 1, "actions=%d" % boss_actions)

	# ---- action VM semantics ----
	freeze_boss(s); thaw(s); place(s, 1.0); clear_defense(s.P); clear_defense(s.B)
	var walk := s.parse_action("WALK_STRING(2_hooks)")
	var mixed := s.parse_action("MIXED_STRING(4)")
	var herd := s.parse_action("HERD(50cm)")
	_sr("VM expands composite verbs (WALK_STRING 2_hooks -> 4 acts, MIXED_STRING(4) -> 4 punches, HERD(50cm) -> 0.5m)",
		walk.size() == 4 and mixed.size() == 4 and herd.size() == 1 and absf(float(herd[0]["dist"]) - 0.5) < 0.001)
	s.bqueue = []; s.bstate = "IDLE"; s.btimer = 1 << 30
	s._boss_act(s.parse_action("COUNTER_STATE(2s)")[0])
	var cs_armed: bool = s.B["counter_state_t"] > 0 and s.B["guard_t"] > 0
	s.P["busy_t"] = 0; s.P["cmd"] = {}; s.tokens = []; s.flags = {}
	s.step({"punch": "L_STRAIGHT"}); s.B["dodge_plan"] = []; s.B["dodge_at"] = 0; s.B["dodge"] = ""
	land(s)
	_sr("VM COUNTER_STATE: a punch into his guard is answered at once", cs_armed and s.bstate == "ACTING" and s.bqueue.size() >= 1 and s.bqueue[0]["kind"] == "punch",
		"state=%s queue=%d" % [s.bstate, s.bqueue.size()])
	freeze_boss(s); thaw(s); place(s, 1.0); s.P["pos"] = Vector2(2.0, 0.5); s.B["pos"] = Vector2(2.0, -0.5)
	var px0: float = s.P["pos"].x
	s._boss_act(s.parse_action("CLINCH_ATTEMPT")[0])
	var started: bool = s.clinch.size() > 0 and s.clinch["by"] == "B" and s.P["busy_t"] >= s.clinch_t
	run_ticks(s, s.clinch_t + 2)                      # no taps: he wins the scramble
	_sr("VM CLINCH_ATTEMPT starts a scramble; untapped, he wins and drags you ropeward", started and s.clinch.is_empty() and s.P["pos"].x > px0,
		"x %.2f -> %.2f" % [px0, s.P["pos"].x])
	# ---- sensors parsed from the pattern's own hooks ----
	freeze_boss(s); thaw(s); place(s); clear_defense(s.P); s.P["comp"] = s.P["comp_max"]; s.events.clear(); s.passive_t = 0
	var need := TNBSim.ms(float(s.sensors["passive_s"]) * 1000.0)
	var fired_at := -1
	for i in need * 2:
		s.step({})
		if fired_at < 0 and count_events(s.events, "sensor", {"name": "player_passive"}) > 0: fired_at = i + 1
		if fired_at > 0 or s.mode != "FIGHT": break
	_sr("sensor: player_passive fires at this boss's own threshold (%.0fs), never early" % float(s.sensors["passive_s"]),
		fired_at >= need, "fired after %d steps (threshold %d fight ticks)" % [fired_at, need])

	# ---- dual layer ----
	s.mode = "FIGHT"; s.eight = {}
	s.contributed = 30.0; s.tension = 42.0
	s._end_segment("smoke-forced")
	_sr("segment end enters CORNER", s.mode == "CORNER")
	_sr("relay CHARGED at >=25 contributed", s.charged)
	s.step({"corner": 1})
	_sr("rotation loads the next fighter", s.pname() == "PRIYA", s.pname())
	_sr("tension persists across segments", s.tension == 42.0, "%.0f" % s.tension)
	_sr("CHARGED entrance: surge, first hissatsu half cost, T3 unlocked", s.P["charge_t"] > 0 and absf(s.hiss_cost(s.player_move()) - 5.0) < 0.01 and s.t3_unlocked, "First Snap T0 costs %.1f" % s.hiss_cost(s.player_move()))
	s.contributed = 0.0
	s._end_segment("smoke-forced")
	_sr("no relay under 25 contributed", not s.charged)
	s.step({"corner": 2})
	_sr("seg3 loads MARCUS (rested)", s.pname() == "MARCUS" and s.P["stamina"] > 100.0, "%s stam=%.0f" % [s.pname(), s.P["stamina"]])
	s.score_p = 2; s.score_b = 1; s.ep_p = 40; s.ep_b = 22
	s._end_segment("smoke-forced")
	_sr("dual verdict on score after 3 segments", s.mode == "OVER" and "MILLBROOK WINS" in s.feed)
	s.new_dual()
	_sr("new dual resets to R1", s.mode == "FIGHT" and s.seg_idx == 0 and s.drops_p == 0)
	if gauge_boss: s.wall["B"] = {}

	# ---- zones ----
	var zc := s.zone(Vector2(0, 1.0)) == "CENTER" and s.zone(Vector2(2.0, 0)) == "MID" \
		and s.zone(Vector2(3.3, 0)) == "ROPES" and s.zone(Vector2(3.3, 3.3)) == "CORNER"
	_sr("zone classification (4 zones)", zc)
	freeze_boss(s); clear_defense(s.P); s.trapped_p = false
	s.P["comp"] = s.P["comp_max"]; s.P["pos"] = Vector2(0, 0.8); s.B["pos"] = Vector2(0, -0.8)
	boss_lands(s, "R_STRAIGHT")
	var d_center: float = s.P["comp_max"] - s.P["comp"]
	s.P["comp"] = s.P["comp_max"]; s.P["pos"] = Vector2(3.3, 3.3); s.B["pos"] = Vector2(3.3, 3.3) - Vector2(1, 1).normalized() * 1.6
	boss_lands(s, "R_STRAIGHT")
	var d_corner: float = s.P["comp_max"] - s.P["comp"]
	_sr("corner damage x1.5 vs center", absf(d_corner / maxf(0.01, d_center) - 1.5) < 0.05, "%.1f/%.1f" % [d_corner, d_center])

	# ---- trap ----
	s.P["pos"] = Vector2(3.3, 3.3); s.B["pos"] = Vector2(2.2, 2.2); s.trapped_p = true; s.P["comp"] = s.P["comp_max"]
	clear_defense(s.P); s._set_dodge(s.P, "SLIP", 1)
	boss_lands(s, "R_STRAIGHT")
	var base_w := TNBSim.ms(float(s.T["counter_windows_ms"]["slip"]["base"]))
	_sr("trapped slip window x1.4", s.P["counter_t"] == int(base_w * 1.4), "%d ticks" % s.P["counter_t"])
	clear_defense(s.P); s.P["counter_t"] = 0; s.trapped_p = false; s.pinned_p_t = 0

	# ---- herding ----
	place(s); freeze_boss(s); s.tokens = []; s.flags = {}; s.freeze_t = 0
	var by0: float = s.B["pos"].y
	throw_clean(s, "L_STRAIGHT")
	_sr("landed punches herd him back", s.B["pos"].y < by0, "%.2f -> %.2f" % [by0, s.B["pos"].y])
	place(s); clear_defense(s.P); s.P["comp"] = s.P["comp_max"]
	var py0: float = s.P["pos"].y
	boss_lands(s, "R_STRAIGHT")
	_sr("his punches herd you back", s.P["pos"].y > py0, "%.2f -> %.2f" % [py0, s.P["pos"].y])

	# ---- C2 in play: dodges resolve by geometry, not by table ----
	place(s); clear_defense(s.P); s.P["comp"] = s.P["comp_max"]; s.P["counter_t"] = 0
	s._set_dodge(s.P, "SLIP", 1); boss_lands(s, "R_STRAIGHT")
	_sr("C2 slip evades the straight + opens a window", s.P["comp"] == s.P["comp_max"] and s.P["counter_t"] > 0)
	clear_defense(s.P); s.P["counter_t"] = 0
	s._set_dodge(s.P, "DUCK", 1); boss_lands(s, "R_UPPERCUT")
	_sr("C2 duck eats the uppercut", s.P["comp"] < s.P["comp_max"])
	clear_defense(s.P); s.P["comp"] = s.P["comp_max"]; s.trapped_p = true; s.pinned_p_t = 3200
	s._set_dodge(s.P, "WEAVE", 1); boss_lands(s, "R_HOOK")
	_sr("C2 weave-away evades the hook + escapes the trap", s.P["comp"] == s.P["comp_max"] and not s.trapped_p and s.pinned_p_t == 0)
	clear_defense(s.P); s.P["counter_t"] = 0

	# ---- counter teeth ----
	place(s); freeze_boss(s); thaw(s)
	s.P["busy_t"] = 0; s.P["cmd"] = {}; s.P["counter_t"] = 60
	s.step({"punch": "R_STRAIGHT"})
	_sr("counter window is consumed by the attempt", s.P["counter_t"] == 0 and s.P["pending"].get("counter", false))
	clear_defense(s.B); land(s)
	var landed := false
	s.B["comp"] = s.B["comp_max"]
	for i in 10:
		thaw(s); s.bstate = "TELL"; s.btimer = 1 << 30; place(s)
		s.P["busy_t"] = 0; s.P["cmd"] = {}; s.P["counter_t"] = 60; s.tokens = []; s.flags = {}
		s.step({"punch": "R_STRAIGHT"}); land(s)       # boss read left live: p_read = 0.05 * 0.25
		if s.B["comp"] < s.B["comp_max"]: landed = true; break
	_sr("counter lands through the fear-reduced read", landed)

	# ================= PAC-054: sensors fire at threshold, never early ==========
	# 1. tempo lock (Chiamaka): six equal punch intervals; five are not enough
	var t1 := make_sim(8, 7); quiet(t1); place(t1)
	var early_ok := true
	for i in 7:
		t1.P["busy_t"] = 0; t1.P["cmd"] = {}; thaw(t1)
		var target: int = t1.tick + (60 if i > 0 else 0)
		while t1.tick < target: t1.step({})
		t1.step({"punch": "L_STRAIGHT"}); clear_defense(t1.B)
		if i < 6 and sensor_count(t1, "player_locks_to_single_tempo") > 0: early_ok = false
	_sr("sensor locks_to_single_tempo: 6 equal intervals fire, 5 never", early_ok and sensor_count(t1, "player_locks_to_single_tempo") == 1)
	var t1b := make_sim(8, 7); quiet(t1b); place(t1b)
	for gap in [0, 60, 90, 60, 120, 60, 90]:
		t1b.P["busy_t"] = 0; t1b.P["cmd"] = {}; thaw(t1b)
		var target2: int = t1b.tick + gap
		while t1b.tick < target2: t1b.step({})
		t1b.step({"punch": "L_STRAIGHT"}); clear_defense(t1b.B)
	_sr("sensor locks_to_single_tempo: a varied cadence never fires", sensor_count(t1b, "player_locks_to_single_tempo") == 0)
	# 2. neutral reset attempt (Deshawn): a full second out past engagement, not leading
	var t2 := make_sim(10, 7); quiet(t2); t2.P["pos"] = Vector2(0, 1.5); t2.B["pos"] = Vector2(0, -1.5)
	run_ticks(t2, TNBSim.ms(1000) - 1, {"move": Vector2(0, 1)})
	var n_early := sensor_count(t2, "player_neutral_reset_attempt")
	t2.step({"move": Vector2(0, 1)})
	_sr("sensor neutral_reset_attempt: fires on the 120th tick out of range, not the 119th", n_early == 0 and sensor_count(t2, "player_neutral_reset_attempt") == 1)
	# 3. casting a Moreau native at Remy (library house_id vs pattern META house)
	var lu: Array = TNBSim.LINEUP_MILLBROOK.duplicate(true); lu[0]["hissatsu"] = "Fevrier"
	var t3 := make_sim(20, 7, lu); freeze_boss(t3); thaw(t3); place(t3); t3.events.clear()
	t3.tension = 100.0; t3.P["busy_t"] = 0; t3.P["cmd"] = {}
	t3.step({"punch": "R_HOOKERCUT", "lb": true})
	_sr("sensor casts_moreau_native: Fevrier at Remy fires and forces Ingot (S3)",
		sensor_count(t3, "player_casts_moreau_native") == 1 and t3.bstate == "TELL" and t3.bstring == "S3", "state=%s string=%s" % [t3.bstate, t3.bstring])
	var t3b := make_sim(20, 7); freeze_boss(t3b); thaw(t3b); place(t3b); t3b.events.clear()
	t3b.tension = 100.0; t3b.P["busy_t"] = 0; t3b.P["cmd"] = {}
	t3b.step({"punch": "R_HOOKERCUT", "lb": true})
	_sr("sensor casts_moreau_native: Aurora Borealis Breaker (no house) never fires", sensor_count(t3b, "player_casts_moreau_native") == 0 and t3b.bstate != "TELL")
	# 4. Marta drops her hands when you refuse to lead; a punch into it is the bait
	var t4 := make_sim(18, 7); thaw(t4); place(t4); t4.events.clear()
	t4.bstate = "IDLE"; t4.btimer = 1; t4.passive_t = TNBSim.ms(3000)
	var stance_seen := false; var guard := 0
	while not stance_seen and guard < 2400:
		t4.step({}); guard += 1
		if t4.hands_down_t > 0: stance_seen = true
	var no_fire_yet: bool = sensor_count(t4, "trap_stance_hands_down") == 0
	t4.P["busy_t"] = 0; t4.P["cmd"] = {}; thaw(t4)
	t4.step({"punch": "L_STRAIGHT"})
	_sr("sensor trap_stance_hands_down: she offers the stance idle; a punch into it forces Mirror (S1)",
		stance_seen and no_fire_yet and sensor_count(t4, "trap_stance_hands_down") == 1 and t4.bstring == "S1" and t4.bstate == "TELL",
		"stance after %d ticks, state=%s" % [guard, t4.bstate])
	var t4b := make_sim(18, 7); quiet(t4b); place(t4b); t4b.hands_down_t = 0
	t4b.P["busy_t"] = 0; t4b.P["cmd"] = {}; t4b.step({"punch": "L_STRAIGHT"})
	_sr("sensor trap_stance_hands_down: hands up, no bait", sensor_count(t4b, "trap_stance_hands_down") == 0)
	# 5. Tam's fake tells in phase 1; reacting to one is the bait
	var t5 := make_sim(22, 7); thaw(t5); place(t5); t5.events.clear(); t5.bstate = "IDLE"; t5.btimer = 1
	run_ticks(t5, TNBSim.ms(20000))
	var fakes := count_events(t5.events, "tell", {"fake": true})
	var t5b := make_sim(22, 7); thaw(t5b); place(t5b); t5b.events.clear()
	t5b.bstate = "FAKE"; t5b.bstring = "S1"; t5b.btimer = 200
	run_ticks(t5b, 30)
	var quiet_ok: bool = sensor_count(t5b, "player_reacts_to_fake_tell") == 0
	t5b.step({"dodge": "SLIP_L"})
	_sr("sensor reacts_to_fake_tell: phase-1 fakes exist (%d in 20s); ignoring one is safe; flinching forces S2" % fakes,
		fakes >= 1 and quiet_ok and sensor_count(t5b, "player_reacts_to_fake_tell") == 1 and t5b.bstate == "TELL" and t5b.bstring == "S2")
	var t5c := make_sim(22, 7); thaw(t5c); place(t5c); t5c.events.clear(); t5c.bphase = 2; t5c.bstate = "IDLE"; t5c.btimer = 1
	run_ticks(t5c, TNBSim.ms(20000))
	_sr("sensor reacts_to_fake_tell: phase 2 retires the borrowed clothes (0 fakes in 20s)", count_events(t5c.events, "tell", {"fake": true}) == 0)
	# 6. audio-assist reliance (Choir): three sub-300ms reactions WITH the assist on
	for assist in [true, false]:
		var t6 := make_sim(15, 7); quiet(t6); place(t6)
		var early6 := true
		for i in 3:
			t6._force_string("S1", 1.0, false)
			run_ticks(t6, 4, {"audio_assist": assist})
			t6.step({"audio_assist": assist, "dodge": "DUCK"})
			if i < 2 and sensor_count(t6, "player_audio_assist_reliance") > 0: early6 = false
			t6.bstate = "IDLE"; t6.btimer = 1 << 30
			run_ticks(t6, 40, {"audio_assist": assist})
		if assist:
			_sr("sensor audio_assist_reliance: fires on the 3rd fast reaction with the assist on, not the 2nd", early6 and sensor_count(t6, "player_audio_assist_reliance") == 1)
		else:
			_sr("sensor audio_assist_reliance: the same reactions without the assist never fire", sensor_count(t6, "player_audio_assist_reliance") == 0)
	# 7. clinch input spam (Alfie) + the referee's holding call
	var t7 := make_sim(5, 7); quiet(t7); place(t7, 1.0)
	var ep0: int = t7.ep_p
	t7.step({"clinch": true}); run_ticks(t7, 29); t7.step({"clinch": true}); run_ticks(t7, 29)
	var early7: bool = sensor_count(t7, "player_clinch_input_spam") == 0 and t7.ep_p == ep0
	t7.step({"clinch": true})
	_sr("sensor clinch_input_spam: third grab in 8s fires + referee holding call (-2 EP); two do not",
		early7 and sensor_count(t7, "player_clinch_input_spam") == 1 and t7.ep_p == ep0 - 2 and count_events(t7.events, "referee") == 1)
	# 8. sprint approach: 0.8m burst toward him, -4 stamina
	var t8 := make_sim(18, 7); quiet(t8); place(t8, 2.4)
	var st0: float = t8.P["stamina"]; var d8: float = t8.P["pos"].distance_to(t8.B["pos"])
	t8.step({"sprint": true})
	_sr("sensor sprint_approach: a sprint-step toward him fires; 0.8m closed, -4 stamina",
		sensor_count(t8, "player_sprint_approach") == 1 and absf((d8 - t8.P["pos"].distance_to(t8.B["pos"])) - 0.8) < 0.05 and absf(st0 - t8.P["stamina"]) > 3.9,
		"closed %.2fm" % (d8 - t8.P["pos"].distance_to(t8.B["pos"])))
	# 9. straight-line retreat: 1.2m of backing without an angle
	var t9 := make_sim(19, 7); quiet(t9); place(t9, 1.6)
	var fired_at_d := -1.0; var prev_d := 0.0
	for i in 400:
		prev_d = t9.retreat_d
		t9.step({"move": Vector2(0, 1)})
		if sensor_count(t9, "player_straight_line_retreat") > 0: fired_at_d = prev_d; break
	_sr("sensor straight_line_retreat: fires on the step that completes 1.2m, never before", fired_at_d >= 0.0 and fired_at_d < 1.2 and fired_at_d > 1.2 - 0.05, "%.3fm before the firing step" % fired_at_d)
	var t9b := make_sim(19, 7); quiet(t9b); place(t9b, 1.6)
	run_ticks(t9b, 300, {"move": Vector2(0.8, 0.6)})
	_sr("sensor straight_line_retreat: an angled retreat never fires", sensor_count(t9b, "player_straight_line_retreat") == 0)
	# 10. back-step chain (Deshawn): three sprint-steps away inside 4s
	var t10 := make_sim(10, 7); quiet(t10); place(t10, 1.2)
	for i in 3:
		t10.step({"sprint": true, "move": Vector2(0, 1)})
		if i < 2 and sensor_count(t10, "player_backstep_chain3") > 0: early_ok = false
		run_ticks(t10, 59)
		t10.P["pos"] = Vector2(0, 0.6); t10.B["pos"] = Vector2(0, -0.6)
	_sr("sensor backstep_chain3: the third back-step fires, the second does not", early_ok and sensor_count(t10, "player_backstep_chain3") == 1)
	# 11. rope backing (Cassidy): backing INTO the ropes vs sliding along into them
	var t11 := make_sim(0, 7); quiet(t11); t11.P["pos"] = Vector2(0, 2.8); t11.B["pos"] = Vector2(0, 1.2); t11.last_zone_p = "MID"
	run_ticks(t11, 60, {"move": Vector2(0, 1)})
	var t11b := make_sim(0, 7); quiet(t11b); t11b.P["pos"] = Vector2(1.6, 2.5); t11b.B["pos"] = Vector2(1.6, 0.9); t11b.last_zone_p = "MID"
	for i in 90:                                       # he stays square to you while you slide along the rope line
		t11b.B["pos"] = Vector2(t11b.P["pos"].x, 0.9)
		t11b.step({"move": Vector2(-1, 0)})
	_sr("sensor rope_backing: backing onto the ropes fires; sliding sideways onto them is only rope_touch",
		sensor_count(t11, "player_rope_backing") == 1 and sensor_count(t11, "player_rope_touch") == 1 and sensor_count(t11b, "player_rope_backing") == 0 and sensor_count(t11b, "player_rope_touch") == 1)
	# 12. referee ladder: Alfie banks exactly two warnings, never the third; warnings_banked==2 is his phase 2
	var t12 := make_sim(5, 7); quiet(t12); place(t12, 1.0)
	var ep_b0: int = t12.ep_b
	var w1 := 0; var w2 := 0; var w3 := 0
	for i in 3:
		place(t12, 1.0); t12._boss_act(t12.parse_action("CLINCH_ATTEMPT")[0])
		run_ticks(t12, t12.clinch_t + 2)
		if i == 0: w1 = t12.bwarnings
		if i == 1: w2 = t12.bwarnings
		if i == 2: w3 = t12.bwarnings
		t12.bstate = "IDLE"; t12.btimer = 1; t12.step({}); freeze_boss(t12)
	_sr("referee: Alfie banks warning 1 (free), warning 2 (-5 EP), and never a third", w1 == 1 and w2 == 2 and w3 == 2 and t12.ep_b == ep_b0 - 5, "warnings %d/%d/%d ep_b %d" % [w1, w2, w3, t12.ep_b])
	_sr("phase trigger warnings_banked==2 reached (dirty flirtation stops)", t12.bphase == 2, "phase=%d" % t12.bphase)
	var pc2 := t12.phase_coverage(t12.patterns)
	_sr("phase-trigger vocabulary fully executable (13/13 forms)", pc2["unknown"].is_empty(), "%d forms" % pc2["known"].size())
	# 13. the clinch scramble from the player's side: taps on the cue win position or a reset
	var t13 := make_sim(0, 7); quiet(t13); place(t13, 1.0)
	t13.step({"clinch": true})
	var began: bool = t13.clinch.size() > 0 and t13.clinch["by"] == "P"
	var cues: Array = t13.clinch["cues"].duplicate(); var wins: Array = t13.clinch["windows"].duplicate()
	var bx0: Vector2 = t13.B["pos"]
	play_clinch(t13, "sides")
	var won_pos: bool = count_events(t13.events, "clinch_end", {"winner": "P"}) == 1 and t13.B["pos"] != bx0
	var t13b := make_sim(0, 7); quiet(t13b); place(t13b, 1.0); t13b.P["stamina"] = 50.0
	t13b.step({"clinch": true}); play_clinch(t13b, "enter", true)
	var won_reset: bool = count_events(t13b.events, "clinch_end", {"winner": "P", "reset": true}) == 1 and t13b.P["stamina"] > 54.0
	_sr("clinch scramble: alternating taps on the cue win position (he is walked ropeward); ENTER parity + BODY wins a reset (+5 stamina)", began and won_pos and won_reset)
	var t13c := make_sim(0, 7); quiet(t13c); place(t13c, 1.0)
	t13c.step({"clinch": true}); play_clinch(t13c, "none")
	_sr("clinch scramble: no taps loses it (dragged ropeward)", count_events(t13c.events, "clinch_end", {"winner": "B"}) == 1)

	# ================= PAC-055: fouls both ways, the shrinking cue, the survival grab ==========
	# shrinking cue: intervals 0.8x each, windows 30% of the interval, floored by RFX; the last cue is RFX's
	var shrink_ok := true
	for k in range(1, cues.size()):
		var iv_prev: int = int(cues[k - 1]) - (int(cues[k - 2]) if k >= 2 else 0)
		var iv: int = int(cues[k]) - int(cues[k - 1])
		if iv >= iv_prev: shrink_ok = false
	var floor_rory := int(lerpf(float(TNBSim.ms(80)), float(TNBSim.ms(160)), 50.0 / 99.0))
	var floored := true
	for w in wins:
		if int(w) < floor_rory: floored = false
	_sr("clinch cue shrinks (%s ticks) and every window stays above the RFX floor (%d)" % [",".join(PackedStringArray(cues.map(func(x): return str(x)))), floor_rory], shrink_ok and floored and int(wins[-1]) == floor_rory,
		"windows " + ",".join(PackedStringArray(wins.map(func(x): return str(x)))))
	var lu2: Array = TNBSim.LINEUP_MILLBROOK.duplicate(true); lu2[0]["stats"]["RFX"] = 70
	var t14 := make_sim(0, 7, lu2); quiet(t14); place(t14, 1.0); t14.step({"clinch": true})
	_sr("RFX decides the last cue: RFX 70 gets a wider final window than RFX 50", int(t14.clinch["windows"][-1]) > int(wins[-1]), "%d vs %d ticks" % [int(t14.clinch["windows"][-1]), int(wins[-1])])
	var t15 := make_sim(0, 7); quiet(t15); place(t15, 1.0); t15.step({"clinch": true}); play_clinch(t15, "wrong")
	var t15b := make_sim(0, 7); quiet(t15b); place(t15b, 1.0); t15b.step({"clinch": true}); play_clinch(t15b, "mash")
	_sr("clinch: the wrong side spends the cue; mashing ahead of the cue locks it - both lose",
		count_events(t15.events, "clinch_miss", {"why": "wrong_side"}) >= 2 and count_events(t15.events, "clinch_end", {"winner": "B"}) == 1
		and count_events(t15b.events, "clinch_miss", {"why": "early"}) >= 1 and count_events(t15b.events, "clinch_end", {"winner": "B"}) == 1)
	# fouls by geometry: player side
	var f1 := make_sim(0, 7); quiet(f1); place(f1, 1.4)
	f1.P["busy_t"] = 0; f1.P["cmd"] = {}
	f1.step({"punch": "R_STRAIGHT", "body": true}); clear_defense(f1.B); f1.B["dodge"] = "LEAN"; f1.B["dodge_t"] = 999
	land(f1)
	var loss_foul := 0.0
	for e in f1.events:
		if e["kind"] == "hit": loss_foul = float(e["dmg"])
	var lowblow: bool = count_events(f1.events, "foul", {"who": "P", "foul": "low_blow"}) == 1 and f1.pwarnings == 1
	thaw(f1); place(f1, 1.4); clear_defense(f1.B); f1.events.clear()
	f1.P["busy_t"] = 0; f1.P["cmd"] = {}; f1.tokens = []; f1.flags = {}
	f1.step({"punch": "R_STRAIGHT", "body": true}); clear_defense(f1.B)
	land(f1)
	var loss_clean := 0.0
	for e in f1.events:
		if e["kind"] == "hit": loss_clean = float(e["dmg"])
	_sr("foul: a body punch into his lean-back is a LOW BLOW (half damage, warning 1, no EP); the same punch clean is not",
		lowblow and count_events(f1.events, "foul") == 0 and absf(loss_foul * 2.0 - loss_clean) < 0.01, "%.2f vs %.2f" % [loss_foul, loss_clean])
	thaw(f1); place(f1, 1.4); f1.events.clear(); f1.P["busy_t"] = 0; f1.P["cmd"] = {}; f1.tokens = []; f1.flags = {}
	f1.step({"punch": "R_STRAIGHT"}); clear_defense(f1.B); f1.B["dodge"] = "LEAN"; f1.B["dodge_t"] = 999; land(f1)
	_sr("foul: a head punch into the lean-back is legal", count_events(f1.events, "foul") == 0 and count_events(f1.events, "hit", {"on": "B"}) == 1)
	var f2 := make_sim(0, 7); quiet(f2); place(f2, 1.4)
	var results := {}
	for row in ["R_FLARED", "R_UPPERCUT", "R_STRAIGHT"]:
		thaw(f2); place(f2, 1.4); f2.events.clear(); f2.P["busy_t"] = 0; f2.P["cmd"] = {}; f2.tokens = []; f2.flags = {}; f2.pwarnings = 0
		f2.step({"punch": row}); clear_defense(f2.B); f2.B["dodge"] = "DUCK"; f2.B["dodge_t"] = 999; land(f2)
		results[row] = [count_events(f2.events, "hit", {"on": "B"}), count_events(f2.events, "foul", {"foul": "behind_the_head"})]
	_sr("foul: the overhand onto a ducked head is BEHIND THE HEAD; the uppercut lands clean; the straight misses",
		results["R_FLARED"] == [1, 1] and results["R_UPPERCUT"] == [1, 0] and results["R_STRAIGHT"] == [0, 0], JSON.stringify(results))
	# the ladder, player side: warning, -5 EP, DROP awarded to him
	var f3 := make_sim(0, 7); quiet(f3)
	var ep_p0: int = f3.ep_p; var sb0: int = f3.score_b; var pd0: int = f3.P["drops"]
	var rungs: Array = []
	for k in 3:
		thaw(f3); place(f3, 1.4); f3.P["busy_t"] = 0; f3.P["cmd"] = {}; f3.tokens = []; f3.flags = {}
		f3.step({"punch": "L_HOOK", "body": true}); clear_defense(f3.B); f3.B["dodge"] = "LEAN"; f3.B["dodge_t"] = 999; land(f3)
		rungs.append([f3.pwarnings, f3.ep_p - ep_p0, f3.score_b - sb0])
	_sr("referee ladder runs against the player: warning / -5 EP / DROP awarded (no knockdown counted, fight continues)",
		rungs == [[1, 0, 0], [2, -5, 0], [3, -5, 1]] and f3.P["drops"] == pd0 and f3.mode == "FIGHT", JSON.stringify(rungs))
	# boss side: clean fighters pull it, dirty ones foul until their cap then pull
	var f4 := make_sim(0, 7); quiet(f4); place(f4, 1.4); clear_defense(f4.P); f4.P["comp"] = f4.P["comp_max"]
	f4.P["dodge"] = "LEAN"; f4.P["dodge_t"] = 999
	boss_lands(f4, "R_HOOK", 1.0, true)
	var clean_pulled: bool = count_events(f4.events, "pulled") == 1 and f4.P["comp"] == f4.P["comp_max"] and f4.bwarnings == 0
	var f5 := make_sim(5, 7); quiet(f5); place(f5, 1.4); clear_defense(f5.P); f5.P["comp"] = f5.P["comp_max"]
	f5.P["dodge"] = "LEAN"; f5.P["dodge_t"] = 999
	boss_lands(f5, "R_HOOK", 1.0, true)
	var dirty_fouled: bool = count_events(f5.events, "foul", {"who": "B", "foul": "low_blow"}) == 1 and f5.bwarnings == 1 and f5.P["comp"] < f5.P["comp_max"]
	f5.bwarnings = 2; f5.events.clear(); f5.P["comp"] = f5.P["comp_max"]
	boss_lands(f5, "R_HOOK", 1.0, true)
	var dirty_capped: bool = count_events(f5.events, "pulled") == 1 and f5.bwarnings == 2 and f5.P["comp"] == f5.P["comp_max"]
	_sr("foul: a clean boss pulls the body shot off your lean; Alfie takes the low blow until his cap, then pulls it", clean_pulled and dirty_fouled and dirty_capped)
	# survival grab: a wobbled boss grabs once per segment at 0-range
	var g1 := make_sim(0, 7); quiet(g1); place(g1, 1.0); g1.B["comp"] = g1.B["comp_max"] * 0.3; g1.bstate = "IDLE"
	g1.step({})
	var grabbed: bool = g1.clinch.size() > 0 and g1.clinch["by"] == "B" and count_events(g1.events, "survival_grab") == 1 and g1.bsurvival_used
	play_clinch(g1, "none")
	place(g1, 1.0); g1.B["comp"] = g1.B["comp_max"] * 0.3; g1.bstate = "IDLE"; g1.btimer = 1 << 30; g1.events.clear()
	run_ticks(g1, 30)
	var once: bool = g1.clinch.is_empty() and count_events(g1.events, "survival_grab") == 0
	g1.mode = "FIGHT"; g1._end_segment("smoke-forced"); g1.step({"corner": 1})
	_sr("survival grab: a wobbled boss grabs at 0-range, once per segment; the next segment re-arms it", grabbed and once and not g1.bsurvival_used)
	var g2 := make_sim(0, 7); quiet(g2); place(g2, 2.0); g2.B["comp"] = g2.B["comp_max"] * 0.3; g2.bstate = "IDLE"
	run_ticks(g2, 5)
	_sr("survival grab: never from outside 0-range", g2.clinch.is_empty() and count_events(g2.events, "survival_grab") == 0)
	# wobble: movement at 70% below 35% composure
	var wb := make_sim(0, 7); quiet(wb); place(wb, 1.6); var x0: float = wb.P["pos"].x
	run_ticks(wb, 20, {"move": Vector2(1, 0)}); var d_full: float = absf(wb.P["pos"].x - x0)
	place(wb, 1.6); wb.P["comp"] = wb.P["comp_max"] * 0.3; x0 = wb.P["pos"].x
	run_ticks(wb, 20, {"move": Vector2(1, 0)}); var d_wob: float = absf(wb.P["pos"].x - x0)
	_sr("wobble: below 35pct composure the feet move at 70pct", absf(d_wob / maxf(0.001, d_full) - 0.7) < 0.02, "%.3f/%.3f" % [d_wob, d_full])

	# ================= PAC-056: the hissatsu VM executes the library ==========
	var ec := s.effect_coverage(s.library)
	_sr("effect VM has a handler for every effect type / STATE / BUFF in the library (%d moves, %d sealed)" % [ec["moves"], ec["sealed"]],
		ec["unknown"].is_empty() and ec["moves"] == 87 and ec["sealed"] == 3, "" if ec["unknown"].is_empty() else JSON.stringify(ec["unknown"]))
	var desp_ok := 0; var desp_absent := 0; var desp_bad: Array = []
	for name in s.patterns:
		var d = s.patterns[name].get("desperation")
		if d == null or d.has("authored_absent"): desp_absent += 1
		elif s.library.has(str(d["move"])): desp_ok += 1
		else: desp_bad.append(name)
	_sr("every boss desperation resolves to a library record (%d cast by name, %d authored-absent)" % [desp_ok, desp_absent], desp_bad.is_empty() and desp_ok + desp_absent == 24, JSON.stringify(desp_bad))
	# interrupts: Yuri's Grain Elevator (RISE, 1500ms windup, window 700ms)
	var h1 := make_sim(1, 7); quiet(h1); place(h1, 1.4)
	var armed_b := boss_desperation(h1)
	var move_named: bool = armed_b and str(h1.cast["move"]["name"]) == "Grain Elevator" and int(h1.cast["total"]) == TNBSim.ms(1500)
	var ten0: float = h1.tension
	h1.P["busy_t"] = 0; h1.P["cmd"] = {}; h1.step({"punch": "L_STRAIGHT"}); clear_defense(h1.B); land(h1)   # jab lands ~20 ticks in: inside the window
	_sr("boss desperation casts BY NAME from the library; a jab inside the window breaks it (+5 Tension, flash window)",
		move_named and h1.cast.is_empty() and count_events(h1.events, "cast_interrupted") == 1 and h1.tension > ten0 and h1.P["flash_t"] > 0)
	var h2 := make_sim(1, 7); quiet(h2); place(h2, 1.4); boss_desperation(h2)
	run_ticks(h2, TNBSim.ms(700) + 5)                     # past the window
	var v_g0: float = h2.P["guard"]
	h2.P["busy_t"] = 0; h2.P["cmd"] = {}; h2.step({"punch": "L_STRAIGHT"}); clear_defense(h2.B); land(h2)
	var late_ok: bool = count_events(h2.events, "cast_interrupted") == 0
	resolve_cast(h2)
	_sr("after the window the cast is committed: it resolves (DMG x2.0 + SHRED 40 on your guard)", late_ok and count_events(h2.events, "hit", {"hissatsu": true}) == 1 and absf((v_g0 - h2.P["guard"]) - 40.0) < 0.01, "guard %.1f -> %.1f" % [v_g0, h2.P["guard"]])
	var h3 := make_sim(1, 7); quiet(h3); place(h3, 1.4); boss_desperation(h3)
	h3.P["busy_t"] = 0; h3.P["cmd"] = {}; h3.step({"punch": "R_HOOK"}); clear_defense(h3.B); land(h3)
	_sr("only jab-class punches interrupt: a hook in the window does not", h3.cast.size() > 0 and count_events(h3.events, "cast_interrupted") == 0)
	# s9 at resolve: full / perfect slip 40% / block 60% + heavy shred
	var v_full := make_sim(1, 7); quiet(v_full); place(v_full, 1.4); boss_desperation(v_full); clear_defense(v_full.P); resolve_cast(v_full)
	var v_d_full := hit_dmg(v_full, "P")
	var slipd := make_sim(1, 7); quiet(slipd); place(slipd, 1.4); boss_desperation(slipd)
	run_ticks(slipd, int(slipd.cast["t"]) - 10); slipd.P["dodge"] = "SLIP"; slipd.P["dodge_dir"] = 1; slipd.P["dodge_t"] = 40; resolve_cast(slipd)
	var d_slip := hit_dmg(slipd, "P")
	var blk := make_sim(1, 7); quiet(blk); place(blk, 1.4); boss_desperation(blk)
	run_ticks(blk, int(blk.cast["t"]) - 30); var gb0: float = blk.P["guard"]
	while blk.cast.size() > 0: blk.step({"block": true})
	var d_blk := hit_dmg(blk, "P")
	_sr("s9 resolve: full %.1f, perfect slip chips 40%% (%.1f), block takes 60%% + heavy shred (%.1f, guard -50%% on top of the move's own SHRED 40)" % [v_d_full, d_slip, d_blk],
		v_d_full > 0.0 and absf(d_slip - v_d_full * 0.4) < 0.05 and absf(d_blk - v_d_full * 0.6) < 0.05 and absf((gb0 - blk.P["guard"]) - (blk.P["guard_max"] * 0.5 + 40.0)) < 1.0,
		"counter window after the slip: %d ticks" % slipd.P["counter_t"])
	# PISTON profile: slip full-evades, block 70% (Rush Hour, 5 hits)
	var rh := make_sim(10, 7); quiet(rh); place(rh, 1.4); boss_desperation(rh); clear_defense(rh.P); resolve_cast(rh)
	var rh_hits := count_events(rh.events, "hit", {"hissatsu": true})
	var rh2 := make_sim(10, 7); quiet(rh2); place(rh2, 1.4); boss_desperation(rh2)
	run_ticks(rh2, int(rh2.cast["t"]) - 10); rh2.P["dodge"] = "SLIP"; rh2.P["dodge_dir"] = 1; rh2.P["dodge_t"] = 40; resolve_cast(rh2)
	_sr("Rush Hour lands as 5 packets; the PISTON profile lets a perfect slip evade in full", rh_hits == 5 and hit_dmg(rh2, "P") == 0.0 and count_events(rh2.events, "hit", {"outcome": "evaded"}) == 5 and rh.states["P"].has("guard_regen_minus1"))
	# walls: Marta's Premiere Neige is not interruptible; it walls your punches for 5s; a T1 cast breaks it at cost parity
	var mw := make_sim(18, 7); quiet(mw); place(mw, 1.4); boss_desperation(mw)
	var not_int: bool = not bool(mw.cast["interruptible"])
	mw.P["busy_t"] = 0; mw.P["cmd"] = {}; mw.step({"punch": "L_STRAIGHT"}); clear_defense(mw.B); land(mw)
	var still_casting: bool = mw.cast.size() > 0
	resolve_cast(mw)
	var wall_up: bool = int(mw.wall["B"].get("timed_t", 0)) > 0 and mw.states["B"].has("auto_slip")
	thaw(mw); mw.P["busy_t"] = 0; mw.P["cmd"] = {}; mw.events.clear(); mw.tokens = []; mw.flags = {}
	mw.step({"punch": "R_HOOK"}); clear_defense(mw.B); land(mw)
	var v_walled: bool = count_events(mw.events, "walled") == 1 and hit_dmg(mw, "B") == 0.0
	mw.tension = 100.0; thaw(mw); mw.P["busy_t"] = 0; mw.P["cmd"] = {}; mw.events.clear()
	mw.step({"punch": "R_HOOKERCUT", "lb": true}); resolve_cast(mw)
	var v_broke: bool = count_events(mw.events, "wall_broken") == 1 and int(mw.wall["B"].get("timed_t", 0)) == 0 and hit_dmg(mw, "B") == 0.0
	_sr("WALL: not interruptible; your punches are walled; a T1 cast breaks it at cost parity (no damage either way)", not_int and still_casting and wall_up and v_walled and v_broke)
	# perfect WALL negates: the player raises Premiere Neige (LB + RT 400ms), then eats a T1 cast into it
	var pw := with_move(1, 7, "Premiere Neige")
	var cast_ok := cast_player(pw)
	resolve_cast(pw)
	var my_wall: bool = cast_ok and int(pw.wall["P"].get("timed_t", 0)) > 0 and pw.states["P"].has("auto_slip")
	pw.events.clear(); place(pw, 1.4); boss_lands(pw, "R_STRAIGHT")
	var walled_me: bool = count_events(pw.events, "walled", {"who": "P"}) == 1 and pw.P["comp"] == pw.P["comp_max"]
	boss_desperation(pw); resolve_cast(pw)
	_sr("perfect WALL: the LB+RT hold casts it; his punches are walled; his T1 cast is negated and breaks the wall",
		my_wall and walled_me and pw.P["comp"] == pw.P["comp_max"] and count_events(pw.events, "wall_broken", {"who": "P"}) == 1)
	# effects one by one
	var ho := make_sim(19, 7); quiet(ho); place(ho, 1.4); boss_desperation(ho); clear_defense(ho.P)   # Moira: Undertow, DISPLACE ROPES 1.5
	var h_py0: Vector2 = ho.P["pos"]; resolve_cast(ho)
	_sr("DISPLACE: Undertow throws you 1.5m toward the nearest rope", count_events(ho.events, "displace", {"toward": "ROPES"}) == 1 and ho.P["pos"].distance_to(h_py0) > 1.0, "%.2fm" % ho.P["pos"].distance_to(h_py0))
	var bu := make_sim(4, 7); quiet(bu); place(bu, 1.4); boss_desperation(bu); clear_defense(bu.P); var v_st0: float = bu.P["stamina"]; resolve_cast(bu)
	_sr("BURN: Heat Advisory burns 20 stamina", absf((v_st0 - bu.P["stamina"]) - 20.0) < 0.6, "%.1f" % (v_st0 - bu.P["stamina"]))
	var fs := with_move(0, 7, "First Snap"); cast_player(fs); resolve_cast(fs); thaw(fs)
	fs.P["pos"] = Vector2(0, 1.6); fs.B["pos"] = Vector2(0, -1.6); var bpos0: Vector2 = fs.B["pos"]
	run_ticks(fs, 20); var d_slow: float = fs.B["pos"].distance_to(bpos0)
	var fs2 := make_sim(0, 7); quiet(fs2); fs2.P["pos"] = Vector2(0, 1.6); fs2.B["pos"] = Vector2(0, -1.6); bpos0 = fs2.B["pos"]
	run_ticks(fs2, 20); var d_norm: float = fs2.B["pos"].distance_to(bpos0)
	_sr("STATE foot_freeze_slow: First Snap slows his feet to 60%", fs.states["B"].has("foot_freeze_slow") and absf(d_slow / maxf(0.001, d_norm) - 0.6) < 0.03, "%.3f/%.3f" % [d_slow, d_norm])
	var bi := with_move(0, 7, "Black Ice"); cast_player(bi); resolve_cast(bi)
	_sr("STATE tell_jam on him: Black Ice drops his read to 5% for 3s", bi.states["B"].has("tell_jam_audio") and absf(bi.read_prob(0, false, false, false) - 0.05) < 0.001)
	var ch := make_sim(8, 7); quiet(ch); place(ch, 1.4); boss_desperation(ch); clear_defense(ch.P); resolve_cast(ch)
	ch.events.clear(); ch._force_string("S1", 1.0, false)
	_sr("STATE tell_jam on you: after Harmattan his tells are emitted jammed (drawn blind)", ch.states["P"].has("tell_jam_visual") and count_events(ch.events, "tell", {"jammed": true}) == 1)
	var se := with_move(0, 7, "Sorry Eh"); cast_player(se); resolve_cast(se)
	var v_stance: bool = se.P["counter_state_t"] > 0
	se.events.clear(); place(se, 1.4); run_ticks(se, 30, {"block": true}); boss_lands(se, "R_STRAIGHT")
	_sr("STATE counter_stance: Sorry Eh arms you; his next punch into your guard opens a flash window", v_stance and se.P["flash_t"] > 0)
	var tm := make_sim(16, 7); quiet(tm); place(tm, 1.4); boss_desperation(tm); clear_defense(tm.P); resolve_cast(tm)     # Vasile: The Mean
	thaw(tm); tm.events.clear(); place(tm, 1.4); throw_clean(tm, "L_STRAIGHT"); var jab_d := hit_dmg(tm, "B")
	thaw(tm); tm.events.clear(); place(tm, 1.4); throw_clean(tm, "R_HOOKERCUT"); var hay_d := hit_dmg(tm, "B")
	_sr("STATE averages_incoming_damage: under The Mean your haymaker lands for the jab's average (%.1f vs %.1f)" % [hay_d, jab_d], tm.states["B"].has("averages_incoming_damage_over_duration") and absf(hay_d - jab_d) < 0.01)
	var lw := with_move(0, 7, "Long Winter"); cast_player(lw); resolve_cast(lw); thaw(lw); lw.P["busy_t"] = 0
	lw.P["stamina"] = 50.0; var v_s0: float = lw.P["stamina"]; run_ticks(lw, 120); var gain_buff: float = lw.P["stamina"] - v_s0
	var lw2 := make_sim(0, 7); quiet(lw2); lw2.P["stamina"] = 50.0; run_ticks(lw2, 120); var gain_norm: float = lw2.P["stamina"] - 50.0
	_sr("BUFF stamina_regen_x2: Long Winter doubles your stamina regen for 4s", lw.buffs["P"].has("stamina_regen_x2") and absf(gain_buff / maxf(0.001, gain_norm) - 2.0) < 0.05, "%.2f vs %.2f" % [gain_buff, gain_norm])
	var cr := with_move(0, 7, "Chinook Rush"); cast_player(cr); resolve_cast(cr); thaw(cr); cr.P["busy_t"] = 0
	var v_px0: Vector2 = cr.P["pos"]; run_ticks(cr, 20, {"move": Vector2(1, 0)}); var glide: float = cr.P["pos"].distance_to(v_px0)
	var cr2 := make_sim(0, 7); quiet(cr2); v_px0 = cr2.P["pos"]; run_ticks(cr2, 20, {"move": Vector2(1, 0)}); var h_walk: float = cr2.P["pos"].distance_to(v_px0)
	_sr("BUFF forward_glide: Chinook Rush moves you at 150% for 2s", cr.buffs["P"].has("forward_glide") and absf(glide / maxf(0.001, h_walk) - 1.5) < 0.05)
	var ps := with_move(0, 7, "Perfect Score"); cast_player(ps); var t_before: float = ps.tension; resolve_cast(ps)
	_sr("BUFF tension_plus_on_hit: Perfect Score pays +5 Tension when it lands", count_events(ps.events, "hit", {"hissatsu": true}) == 1 and absf((ps.tension - t_before) - 5.0) < 0.01)
	var fk := with_move(0, 7, "The Forks"); cast_player(fk); resolve_cast(fk)
	_sr("STATE two_hit_echo: The Forks lands twice", count_events(fk.events, "hit", {"hissatsu": true}) == 2)
	var tf := with_move(0, 7, "Timberfall"); cast_player(tf)
	run_ticks(tf, int(tf.cast["t"]) - 10); tf.B["dodge"] = "DUCK"; tf.B["dodge_t"] = 60; resolve_cast(tf)
	_sr("beats_duck_reads: a RISE into a ducking head lands full (the duck eats the uppercut by geometry, C2)", count_events(tf.events, "hit", {"outcome": "full"}) == 1)
	var ns := with_move(0, 7, "Relay: North Star")
	var v_locked: bool = not ns.castable(ns.player_move())
	ns.t3_unlocked = true; ns.relay_chain = 2
	cast_player(ns); resolve_cast(ns)
	var ns_d := hit_dmg(ns, "B")
	var v_expect := 15.0 * (45.0 / 50.0) * (1.6 + 0.8 * 2.0)
	_sr("T3 needs the CHARGED unlock; North Star scales with the relay chain (base 1.6 + 0.8 x 2 links)", v_locked and absf(ns_d - v_expect) < 0.05, "%.2f vs %.2f" % [ns_d, v_expect])
	var cc := make_sim(9, 7); quiet(cc); place(cc, 1.4); boss_desperation(cc)
	_sr("arm_only: the Commissioner arms [SEALED-SECRET] and casts The Commissioner's Due", count_events(cc.events, "cast", {"shown": "[SEALED-SECRET]", "move": "The Commissioner's Due"}) == 1)
	# ---- Wall Gauge (NP_05 s8): Sam Tagaq ----
	var sg := make_sim(3, 7); quiet(sg); place(sg, 1.4)
	var g_start: float = sg.wall["B"]["pts"]
	var v_c0: float = sg.B["comp"]
	for i in 3: throw_clean(sg, "L_STRAIGHT"); place(sg, 1.4)
	var jabs_zero: bool = float(sg.wall["B"]["pts"]) == g_start and sg.B["comp"] >= v_c0 - 0.01 and sensor_count(sg, "player_jab_spam_on_gauge") == 1
	sg.events.clear(); thaw(sg); sg.P["counter_t"] = 60; throw_clean(sg, "R_STRAIGHT"); place(sg, 1.4)
	var g_after_counter: float = sg.wall["B"]["pts"]; var counter_d := gauge_dmg(sg)
	sg.events.clear(); thaw(sg); throw_clean(sg, "R_HOOK", {"power": true}); place(sg, 1.4)
	var g_after_power: float = sg.wall["B"]["pts"]; var power_d := gauge_dmg(sg)
	sg.events.clear(); thaw(sg); throw_clean(sg, "R_HOOK", {"body": true}); place(sg, 1.4)
	var g_after_body: float = sg.wall["B"]["pts"]; var body_d := gauge_dmg(sg)
	var counter_full := 10.0 * 0.9 * 1.6; var power_full := 12.0 * 0.9 * 1.5; var body_full := 12.0 * 0.9 * 0.8
	_sr("gauge: jabs do 0 (and Sam's literacy hook fires); counters x1.0, power x0.8, body x0.6; his composure is shielded",
		jabs_zero and absf(counter_d - counter_full * 1.0) < 0.01 and absf(power_d - power_full * 0.8) < 0.01 and absf(body_d - body_full * 0.6) < 0.01
		and absf((g_start - g_after_body) - (counter_d + power_d + body_d)) < 0.01 and sg.B["comp"] >= v_c0 - 0.01, "%.0f -> %.1f -> %.1f -> %.1f" % [g_start, g_after_counter, g_after_power, g_after_body])
	sg.wall["B"]["pts"] = 1.0; sg.events.clear(); thaw(sg); sg.P["counter_t"] = 60; throw_clean(sg, "R_STRAIGHT"); place(sg, 1.4)
	var broke_g: bool = count_events(sg.events, "gauge_break") == 1 and int(sg.wall["B"]["open_t"]) > 0 and int(sg.wall["B"]["breaks"]) == 1
	sg.events.clear(); thaw(sg); var cc0: float = sg.B["comp"]; throw_clean(sg, "L_STRAIGHT"); var open_d := hit_dmg(sg, "B")
	var open_amp: bool = absf(open_d - 6.0 * 0.9 * 1.25) < 0.01 and sg.B["comp"] < cc0
	thaw(sg); run_ticks(sg, int(sg.wall["B"]["open_t"]) + 2)
	var reformed: bool = float(sg.wall["B"]["pts"]) == 60.0 and int(sg.wall["B"]["open_t"]) == 0
	sg.wall["B"]["pts"] = 1.0; thaw(sg); place(sg, 1.4); sg.P["counter_t"] = 60; throw_clean(sg, "R_STRAIGHT"); thaw(sg); run_ticks(sg, int(sg.wall["B"]["open_t"]) + 2)
	var reformed2: bool = float(sg.wall["B"]["pts"]) == 30.0
	sg.wall["B"]["pts"] = 1.0; thaw(sg); place(sg, 1.4); sg.P["counter_t"] = 60; sg.events.clear(); throw_clean(sg, "R_STRAIGHT"); thaw(sg); run_ticks(sg, int(sg.wall["B"]["open_t"]) + 2)
	var v_gone: bool = float(sg.wall["B"]["pts"]) == 0.0 and count_events(sg.events, "gauge_gone") == 1 and int(sg.wall["B"]["breaks"]) == 3
	_sr("gauge break: TRUE OPEN 8s at x1.25, reforms 60 then 30, three breaks end it for good", broke_g and open_amp and reformed and reformed2 and v_gone)
	var hg := make_sim(12, 7); quiet(hg); place(hg, 1.4)                                    # HC-0: migrant wall 60, leaves at 40
	var mig0: bool = float(hg.wall["B"]["pts"]) == 60.0
	hg.wall["B"]["pts"] = 41.0; thaw(hg); hg.P["counter_t"] = 60; hg.events.clear(); throw_clean(hg, "R_STRAIGHT")
	var v_left: bool = count_events(hg.events, "gauge_migrate") == 1 and hg.wall["B"].is_empty() and hg.wall_migrate > 0 and hg.wall_migrate <= 40
	hg.mode = "FIGHT"; hg._end_segment("smoke-forced"); hg.step({"corner": 1})
	_sr("migrant wall: HC-0's 60-pt wall leaves him at 40 and meets you again on the next boss", mig0 and v_left and float(hg.wall["B"].get("pts", 0.0)) > 0.0 and hg.wall_migrate == 0, "next boss wall %d" % int(hg.wall["B"].get("pts", 0.0)))

	# ---- PUNISH / BAIT from pattern data ----
	var rc := s.response_coverage(s.patterns)
	_sr("punish-response grammar resolves for every hook (24 patterns)", rc["unknown"].is_empty(),
		"%d responses%s" % [rc["known"], "" if rc["unknown"].is_empty() else "  UNKNOWN: " + JSON.stringify(rc["unknown"])])
	freeze_boss(s); thaw(s); s.punish_cd = {}; s.mode = "FIGHT"
	var pu: Dictionary = s.pattern["punish"][0]
	var plan := s._parse_response(str(pu["response"]))
	var w_pre := JSON.stringify(s.pattern["select"]["weights"])
	s._fire_event(str(pu["trigger"]))
	var answered := false; var detail := ""
	match plan["kind"]:
		"force":
			var full_t := TNBSim.ms(float(s.pattern["strings"][plan["string"]]["tell"]["ms"]))
			answered = s.bstate == "TELL" and s.bstring == plan["string"] and s.btimer < full_t \
				and s.btimer == maxi(1, int(full_t * float(plan["scale"])))
			detail = "%s -> %s tell %d/%d ticks (x%.2f)" % [pu["trigger"], s.bstring, s.btimer, full_t, float(plan["scale"])]
		"actions":
			answered = s.bstate == "ACTING" and s.bqueue.size() >= 1
			detail = "%s -> %d immediate actions" % [pu["trigger"], s.bqueue.size()]
		"swap":
			answered = s.swap_restore.size() > 0 and JSON.stringify(s.pattern["select"]["weights"]) != w_pre
			detail = "%s -> weights swapped for %.0fs" % [pu["trigger"], float(plan["swap"][2])]
		"reweight":
			answered = JSON.stringify(s.pattern["select"]["weights"]) != w_pre
			detail = "%s -> reweighted" % pu["trigger"]
		"locked":
			answered = s.bstate == "IDLE"
			detail = "%s -> %s is phase-locked; nothing fires in phase %d" % [pu["trigger"], plan["locked"], s.bphase]
	_sr("punish hook executes its response (%s)" % plan["kind"], answered, detail)
	_sr("a punished string never comes slower than its full tell", plan["kind"] != "force" or float(plan["scale"]) <= 1.0)
	freeze_boss(s); s.punish_cd = {}
	var baited := false; var bait_full := false
	for b in s.pattern.get("bait", []):
		if b.has("trigger") and b.has("force"):
			s._fire_event(str(b["trigger"]))
			baited = s.bstate == "TELL" and s.bstring == b["force"]
			bait_full = baited and s.btimer == TNBSim.ms(float(s.pattern["strings"][s.bstring]["tell"]["ms"]))
			break
		elif b.has("authored_absent"):
			baited = true; bait_full = true
			break
	_sr("bait hook answers (or authored-absent)", baited)
	_sr("baited string comes at full tell", bait_full)
	return _verdict("SMOKE")

# ------------------------------------------------------------ DETERMINISM ----
func build_log(n: int, seed_v: int) -> Array:
	# a scripted input log: state-free, so three runs see identical intent
	var r := RandomNumberGenerator.new(); r.seed = seed_v
	var out: Array = []
	var mv := Vector2.ZERO; var block := false; var lb := false
	const ROWS := ["L_STRAIGHT", "R_STRAIGHT", "L_HOOK", "R_HOOK", "R_UPPERCUT", "L_UPPERCUT", "R_HOOKERCUT", "R_FLARED", "L_FLARED", "L_HOOKERCUT"]
	const DODGES := ["SLIP_L", "SLIP_R", "DUCK", "LEAN", "WEAVE_L", "WEAVE_R"]
	for i in n:
		if i % 60 == 0: mv = Vector2(r.randf_range(-1, 1), r.randf_range(-1, 1)).limit_length(1.0) if r.randf() < 0.7 else Vector2.ZERO
		if i % 45 == 0: block = r.randf() < 0.55
		if i % 200 == 0: lb = r.randf() < 0.25
		var inp := {"move": mv, "block": block, "lb": lb, "rise": (i % 20) < 10, "corner": 1 + (i % 2), "restart": true}
		if r.randf() < 0.025: inp["punch"] = ROWS[r.randi_range(0, ROWS.size() - 1)]
		if r.randf() < 0.03: inp["dodge"] = DODGES[r.randi_range(0, DODGES.size() - 1)]
		if r.randf() < 0.05: inp["power"] = true
		if r.randf() < 0.05: inp["body"] = true
		if r.randf() < 0.002: inp["taunt"] = true
		if r.randf() < 0.003: inp["sprint"] = true
		if r.randf() < 0.0006: inp["clinch"] = true
		out.append(inp)
	return out

func run_log(s: TNBSim, log_: Array, every: int) -> Array:
	var hashes: Array = []
	for i in log_.size():
		s.step(log_[i])
		if i % every == 0: hashes.append(s.hash_state())
	return hashes

func run_log_jittered(s: TNBSim, log_: Array, every: int, seed_v: int) -> Array:
	# the game loop: frames of 7-40ms fed through TNBClock; ticks pulled from the log
	var r := RandomNumberGenerator.new(); r.seed = seed_v
	var clk := TNBClock.new()
	var hashes: Array = []
	var i := 0
	while i < log_.size():
		var n := clk.advance(r.randf_range(0.007, 0.040))
		for k in n:
			if i >= log_.size(): break
			s.step(log_[i])
			if i % every == 0: hashes.append(s.hash_state())
			i += 1
	return hashes

func determinism() -> int:
	print("DETERMINISM :: C1/C5 - three runs of one input log, hashes every 60 ticks")
	const N := 24000
	var log_ := build_log(N, 777)
	var a := make_sim(1, 12345); a.events.clear()
	var ha := run_log(a, log_, 60)
	var cov := {"hit_B": 0, "hit_P": 0, "counter": 0, "flash": 0, "drop": 0, "eight": 0, "seg_end": 0, "tell": 0, "evade": 0, "block": 0, "interrupt": 0, "clinch": 0, "sprint": 0, "sensor": 0, "foul": 0, "pulled": 0, "survival_grab": 0, "cast_P": 0, "cast_B": 0, "cast_hit": 0, "cast_interrupted": 0}
	for e in a.events:
		match e["kind"]:
			"hit":
				if e["on"] == "B": cov["hit_B"] += 1
				else: cov["hit_P"] += 1
				if e.get("counter", false): cov["counter"] += 1
				if e.get("flash", false): cov["flash"] += 1
			"drop": cov["drop"] += 1
			"eight_beat": cov["eight"] += 1
			"seg_end": cov["seg_end"] += 1
			"tell": cov["tell"] += 1
			"evade": cov["evade"] += 1
			"block": cov["block"] += 1
			"interrupt": cov["interrupt"] += 1
			"clinch": cov["clinch"] += 1
			"sprint": cov["sprint"] += 1
			"sensor": cov["sensor"] += 1
			"foul": cov["foul"] += 1
			"pulled": cov["pulled"] += 1
			"survival_grab": cov["survival_grab"] += 1
			"cast":
				if e["who"] == "P": cov["cast_P"] += 1
				else: cov["cast_B"] += 1
			"cast_interrupted": cov["cast_interrupted"] += 1
	for e in a.events:
		if e["kind"] == "hit" and e.get("hissatsu", false): cov["cast_hit"] += 1
	var duals := 0
	for e in a.events:
		if e["kind"] == "dual_end": duals += 1
	print("  coverage: " + JSON.stringify(cov) + "  duals completed=%d  final mode=%s seg=%d drops %d-%d" % [duals, a.mode, a.seg_idx, a.drops_p, a.drops_b])
	_sr("log exercises both offenses", cov["hit_B"] > 0 and cov["hit_P"] > 0)
	_sr("log exercises hitstop + slow-time (C5 paths)", cov["counter"] > 0 and cov["interrupt"] > 0)
	_sr("log exercises drops / standing-eight / segment end", cov["drop"] > 0 and cov["eight"] > 0 and cov["seg_end"] > 0)
	_sr("log exercises geometric evasion + guard", cov["evade"] > 0 and cov["block"] > 0)
	_sr("log exercises clinch scrambles, sprint-steps and sensors", cov["clinch"] > 0 and cov["sprint"] > 0 and cov["sensor"] > 0)
	_sr("log exercises the referee (fouls or pulled punches) and the survival grab", (cov["foul"] > 0 or cov["pulled"] > 0) and cov["survival_grab"] > 0)
	_sr("log exercises hissatsu casts from the library (player and boss) and their resolve", cov["cast_P"] > 0 and cov["cast_B"] > 0 and cov["cast_hit"] > 0)
	var b := make_sim(1, 12345)
	var hb := run_log(b, log_, 60)
	var same_ab := ha.size() == hb.size() and ha.size() > 0
	var first_diff := -1
	if same_ab:
		for i in ha.size():
			if ha[i] != hb[i]: same_ab = false; first_diff = i; break
	_sr("C1 replay of the log reproduces every state hash (run B == run A)", same_ab,
		"%d hashes" % ha.size() if same_ab else "diverged at hash %d (tick %d)" % [first_diff, first_diff * 60])
	var c := make_sim(1, 12345)
	var hc := run_log_jittered(c, log_, 60, 4242)
	var same_ac := ha.size() == hc.size()
	first_diff = -1
	if same_ac:
		for i in ha.size():
			if ha[i] != hc[i]: same_ac = false; first_diff = i; break
	_sr("C1 jittered 7-40ms frame loop reproduces every state hash (run C == run A)", same_ac,
		"%d hashes" % hc.size() if same_ac else "diverged at hash %d (tick %d)" % [first_diff, first_diff * 60])
	var d := make_sim(1, 54321)
	var hd := run_log(d, log_, 60)
	var differs := hd.size() != ha.size()
	if not differs:
		for i in ha.size():
			if ha[i] != hd[i]: differs = true; break
	_sr("a different seed produces a different trajectory (hash is not degenerate)", differs)
	return _verdict("DETERMINISM")

# --------------------------------------------------------------- GEOMETRY ----
const FAMS := ["STRAIGHT", "FLARED", "HOOK", "HOOKERCUT", "UPPERCUT"]
# dodge label -> [kind, dir relative to the ATTACKING hand: +1 = into it, -1 = away]
const DODGES := {"none": ["", 0], "slip-away": ["SLIP", -1], "slip-into": ["SLIP", 1], "duck": ["DUCK", 1],
	"lean": ["LEAN", 1], "weave-into": ["WEAVE", 1], "weave-away": ["WEAVE", -1]}
# the boxing consensus (NP_14 C2) as a table; H = hit, . = miss. Inside spacing 1.55m.
const EXPECT_INSIDE := {
	"none":       ["H", "H", "H", "H", "H"],
	"slip-away":  [".", ".", ".", ".", "."],
	"slip-into":  [".", ".", "H", "H", "."],
	"duck":       [".", "H", ".", ".", "H"],
	"lean":       ["H", "H", "H", "H", "."],
	"weave-into": [".", ".", ".", "H", "."],
	"weave-away": [".", ".", ".", ".", "."],
}
# at range (1.80m) the lean-back beats everything; neutral still eats all but the uppercut
const EXPECT_RANGE := {"none": ["H", "H", "H", "H", "."], "lean": [".", ".", ".", ".", "."]}

func cell(s: TNBSim, A: Dictionary, D: Dictionary, spacing: float, hand: String, fam: String, dodge: String, body: bool = false) -> String:
	A["pos"] = Vector2(0, 0); D["pos"] = Vector2(0, spacing)
	clear_defense(D)
	var dd: Array = DODGES[dodge]
	if dd[0] != "":
		# "into" the attacking hand: for a right hand the head moves to the DEFENDER's left (dir -1)
		var dir: int = dd[1] * (-1 if hand == "R" else 1)
		D["dodge"] = dd[0]; D["dodge_dir"] = dir; D["dodge_t"] = 10
	var r := s.resolve_geometry(A, D, hand + "_" + fam, body)
	return "H" if r == "HIT" else "."

func geometry() -> int:
	print("GEOMETRY :: C2/C6 - emergent dodge table vs boxing consensus, both fighters, both hands")
	var s := make_sim(0, 1)
	var bad := 0
	for direction in [["boss->player", s.B, s.P], ["player->boss", s.P, s.B]]:
		for hand in ["R", "L"]:
			print("  %s  %s hand  inside 1.55m        STR FLA HOK HKC UPC" % [direction[0], hand])
			for dodge in EXPECT_INSIDE:
				var row := ""; var ok := true
				for i in FAMS.size():
					var got := cell(s, direction[1], direction[2], 1.55, hand, FAMS[i], dodge)
					row += "  " + got + " "
					if got != EXPECT_INSIDE[dodge][i]: ok = false; bad += 1
				print("     %-12s %s %s" % [dodge, row, "" if ok else "   <-- MISMATCH"])
			for dodge in EXPECT_RANGE:
				var row := ""; var ok := true
				for i in FAMS.size():
					var got := cell(s, direction[1], direction[2], 1.80, hand, FAMS[i], dodge)
					row += "  " + got + " "
					if got != EXPECT_RANGE[dodge][i]: ok = false; bad += 1
				print("     %-12s %s %s" % [dodge + "@1.80", row, "" if ok else "   <-- MISMATCH"])
	_sr("C2 emergent table matches the boxing consensus (35 + 10 cells)", bad == 0, "%d mismatches" % bad)
	_sr("C6 identical table in both directions and for both hands", bad == 0)
	# body shots: the slip barely moves the torso; the duck does not lower it
	var body_ok := cell(s, s.P, s.B, 1.55, "R", "STRAIGHT", "slip-away", true) == "H" \
		and cell(s, s.P, s.B, 1.55, "R", "HOOK", "duck", true) == "H" \
		and cell(s, s.P, s.B, 1.80, "R", "STRAIGHT", "lean", true) == "."
	_sr("C2 body shots land through slips and ducks; only distance answers them", body_ok)
	# the boss's read chooses a geometrically valid evasion for every head punch
	var read_bad := 0
	for row in ["L_STRAIGHT", "R_STRAIGHT", "L_FLARED", "R_FLARED", "L_HOOK", "R_HOOK", "L_HOOKERCUT", "R_HOOKERCUT", "L_UPPERCUT", "R_UPPERCUT"]:
		for k in 40:
			var cd := s._correct_dodge_for(row, false)
			s.P["pos"] = Vector2(0, 0); s.B["pos"] = Vector2(0, 1.55)
			clear_defense(s.B); s.B["dodge"] = cd[0]; s.B["dodge_dir"] = cd[1]; s.B["dodge_t"] = 10
			if s.resolve_geometry(s.P, s.B, row, false) == "HIT": read_bad += 1
	_sr("C6 every boss read is a geometrically valid evasion (10 rows x 40 draws)", read_bad == 0, "%d reads would eat the punch" % read_bad)
	# scheduled read: the dodge is live on the impact tick for every startup
	var timing_bad := 0
	for row in ["L_STRAIGHT", "R_HOOK", "R_UPPERCUT", "R_HOOKERCUT"]:
		var t := make_sim(0, 99)
		freeze_boss(t); place(t, 1.6)
		t.P["busy_t"] = 0; t.P["cmd"] = {}
		t.step({"punch": row})
		t.B["dodge_plan"] = ["SLIP", 1]; t.B["dodge_at"] = maxi(1, t.P["pending"]["t"] - 15); t.B["blocking"] = false
		while t.P["pending"].size() > 0 and t.B["dodge_at"] > 0: t.step({})
		var live_at_impact := true
		while t.P["pending"].size() > 0:
			if t.B["dodge"] == "": live_at_impact = false
			t.step({})
		if not live_at_impact: timing_bad += 1
	_sr("C6 a scheduled read is live on the impact tick (jab..haymaker startups)", timing_bad == 0)
	return _verdict("GEOMETRY")
