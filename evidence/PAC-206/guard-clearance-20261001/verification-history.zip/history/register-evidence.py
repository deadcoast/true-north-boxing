import csv,json,sys
from pathlib import Path
csv.field_size_limit(16*1024*1024)
sys.path.insert(0,str(Path('.PACER/tool-runtime/pacer-0.5-c962631/plugins/pacer/src').resolve()))
from pacer_mcp.service import Service
s=Service(Path.cwd());c=s.context('PAC-206',max_bytes=1000000);snap=s.store.load()
ix={r['ID']:r for rows in snap.tables.values() for r in rows}
assert max(int(k[4:]) for k in ix if k.startswith('OVR-'))==1977
assert ix['PAC-206']['Status']=='DOING' and ix['OGM-025']['Status']=='PACED_REQUIREMENT' and not ix['OGM-025']['AcceptanceEvidence']
base='evidence/PAC-206/guard-clearance-20261001/'
assets=[
 ('report.md','Shared return reach and self-clearance repairs, retained failures and unresolved guard motion','OVR-1063;OVR-1140;OVR-1758;OVR-1765;OVR-1865;OVR-1963'),
 ('clearance-checkpoint.json','Learned SWARMER tick3005 saved return reach regression','OVR-1865'),
 ('fold-checkpoint.json','OUTBOXER tick10050 regression for an intermediate constrained route dropping its guarding arm','OVR-1865'),
 ('home-checkpoint.json','Learned BOXERPUNCHER tick6740 normal guard-home clearance through impact','OVR-1865'),
 ('impact-return-checkpoint.json','Ordinary BOXERPUNCHER tick2425 opposite return envelope retained at fractional impact','OVR-1865'),
 ('guard-checkpoint.json','Ordinary BOXERPUNCHER tick2605 unresolved guard lowering replay; elbow limit remains failed','OVR-1865'),
 ('clearance-before.mp4','Turn-start source native return clearance sequence','OVR-1865'),
 ('clearance-after.mp4','Final source native return clearance from identical saved inputs','OVR-1865'),
 ('fold-after.mp4','Final source native folded arm recovery from retained candidate failure state','OVR-1865'),
 ('guard-unresolved.mp4','Final source native unresolved ordinary guard lowering; diagnostic view only','OVR-1865'),
 ('clearance-comparison.png','Six consecutive before/after native return frames from identical inputs','OVR-1865'),
 ('guard-unresolved-sheet.png','Twelve final source frames retaining the unresolved guard lowering','OVR-1865'),
 ('gameplay.mp4','Final source24-second native gameplay camera capture','OVR-1865;OVR-1031'),
 ('inspection.mp4','Final source24-second diagnostic side view of the same exchange','OVR-1865;OVR-1031'),
 ('gameplay-frame.png','Final source gameplay camera at six simulated seconds','OVR-1865;OVR-1031'),
 ('inspection-sheet.png','Twelve final source diagnostic frames across the exchange','OVR-1865;OVR-1031'),
 ('source-hashes.json','244 final source/resource identities for checks and current captures','OVR-1063;OVR-1758;OVR-1865'),
 ('verification-history.zip','CRC-verified source, failed candidates, saved states, test logs and raw frame history','OVR-1063;OVR-1758;OVR-1865')]
ops=[]
for n,(name,purpose,requires) in enumerate(assets,1978):
 id=f'OVR-{n}';assert id not in ix and Path(base+name).is_file(),(id,name)
 ops.append({'op':'add','register':'overlord','row':{'ID':id,'AssetType':'FILE','Path':base+name,'Purpose':purpose,'Requires':requires,'OGMRefs':'OGM-025','PACRefs':'PAC-206','NDLRefs':'NDL-013','Tags':'#boxing #combat #playtest','Notes':'2026-10-01: Core return clearance evidence. Foundation NOT_ACCEPTED; guard lowering remains a failed motion criterion.'}})
 ops.append({'op':'link','id':'NDL-013','field':'TargetOVR','target':id})
 if n!=1978:ops.append({'op':'link','id':'OVR-1978','field':'Requires','target':id})
ops.append({'op':'set','id':'NDL-013','fields':{'NewAssets':';'.join(dict.fromkeys(ix['NDL-013']['NewAssets'].split(';')+[base+n for n,_,_ in assets]))}})
def note(id,text,field='Notes'):
 ops.append({'op':'append','id':id,'field':field,'text':'2026-10-01: '+text})
for id in ['OVR-1063','OVR-1140']:
 note(id,'Solve return reach and own-head clearance together on their sphere intersection. Keep torso/forearm routing inside that envelope by approaching a feasible whole-arm guard home; keep future homes at normal clearance when impact consumes spare margin. Final sustained excess reach0.0137746->8.9407e-8m with zero sampled forearm/head, forearm/torso and glove/torso penetration. '+base+'report.md; NOT_ACCEPTED.')
for id in ['OVR-1758','OVR-1765']:
 note(id,'At held fractional impact clear return reach only for the striking hand. Retain the opposite returning hand envelope through the evaluated-pose solve while preserving the struck endpoint. Replaces prior all-hands return-reach clearing. Exact held-impact excess0.0010128->0m; final contact endpoint error1.33e-7m; repeated solve elbow/wrist drift2.73e-7/1.69e-7m.')
note('OVR-1963','Its remaining return-clearance overreach now repaired through shared solver and opposite-hand impact constraints in '+base+'report.md. Its ordinary BOXERPUNCHER B2633 guard elbow remains unresolved at0.100061m; history retained.')
note('PAC-206','Continued core-only shared return clearance and contact handoff. Final sustained88/88 across86400 input ticks/1330 contact results; excess returning reach reduced from0.0137746m to8.94e-8m, three sampled penetration maxima remain0. All13 previous bounded replays and4 new repaired regressions pass; new guard diagnostic remains7/8 with elbow0.100061m against0.09m limit. Final motion345/345, contact444/444, stance2814/2814, head153/153, attachment128/128 and Northern Rising70/70. Current native frame sequences inspected and six videos decoded;244 source hashes and retained candidate history in '+base+'report.md. No foundation acceptance; DOING retained.')
note('PAC-206','Joint-space guard-hand interpolation worsened saved elbow0.100061->0.104970m and was removed. Initial bounded clearance passed88 geometry checks but introduced OUTBOXER late-return elbow/wrist0.174436/0.162399m: fixed outward torso escape wrapped around the constrained surface. Whole-home feasibility alone and first-exit search on that ray did not fix it. Route toward feasible guard home restored0.058358/0.056959m. Residual apparent2.700mm overreach was a contact-margin change in the stored future home; preserve normal home clearance. Residual1.013mm was actual opposite-hand constraint clearing at impact; retain that envelope. Sources, failures and saved states retained.','PreviousAttempts')
note('PAC-206','Independent collision-free projections need not form a continuous feasible return. Solve skull and reach together, then use a known feasible guard home for torso exit. A bounded curved path is not globally monotonic. Future guard-home clearance and evaluated impact clearance have distinct ownership; the other hand keeps returning at the striking hand contact.','LearningNotes')
note('PAC-206','Still open: ordinary BOXERPUNCHER B2633 guard lowering elbow0.100061m in one tick; rejected guard candidate retained. Outgoing SLUGGER P484 wrist0.110675m is separately recorded, not accepted by geometry. Full authored feel and isolated runtime performance remain unqualified; concurrently loaded timing samples are not a performance acceptance result.')
note('OGM-025','Continued return-clearance repair evidence '+base+'report.md. Remains PACED_REQUIREMENT/NOT_ACCEPTED with empty AcceptanceEvidence. Explicit guard motion failure retained; passing geometric/native fixtures and inspected frames do not establish complete boxing quality.')
note('NDL-013','Existing connected-game lane remains ACTIVE under PAC-206. Added18 registered return-clearance artifacts with final source identity, current native footage, unresolved guard replay and preserved failed candidates. No absorption.')
r=s.apply(ops,actor='codex',revision=snap.revision,onboarding=s.authority()['onboarding'],context=c['receipt'])
result={'revision':r.get('revision'),'validation':s.validate()}
Path('.PACER/guard-clearance-20261001/register-validation.json').write_text(json.dumps(result,default=str,indent=2))
print(json.dumps(result,default=str))
