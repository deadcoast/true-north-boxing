extends SceneTree
const Tests=preload("res://sim/tests.gd")
const Motion=preload("res://presentation/boxing_motion.gd")
func _initialize():
	var tests=Tests.new()
	var saved=JSON.parse_string(FileAccess.get_file_as_string(OS.get_environment("BOXING_WORST")))
	var s=tests.make_sim(0,719);s.restore(saved["snapshot"])
	var f=s.B if saved["who"]=="B" else s.P
	var rig=f["boxing"]["rig"];var before=f["boxing"]["previous_rig"]
	var i=int(saved["detail"]["hand"])
	print("ACTION ",JSON.stringify(f["boxing"]["action"]))
	print("PREPARATION ",JSON.stringify(f["boxing"].get("preparation",{})))
	for pair in [["before",before],["after",rig]]:
		var r=pair[1];var shoulder=r["shoulders"][i];var hand=r["wrists"][i];var axis=(hand-shoulder).normalized()
		var pole=r["arm_poles"][i];var prior=r["support_elbows"][i]-shoulder;prior-=axis*prior.dot(axis)
		var wanted=pole-axis*pole.dot(axis)
		pole=prior.normalized().slerp(wanted.normalized(),minf(0.4,0.18/maxf(prior.angle_to(wanted),0.0001)))
		print(pair[0]," requested_pole ",pole," solved ",r["elbows"][i]-shoulder)
		for key in ["shoulders","wrists","hand_goals","guard_homes","hand_homes","guard_reference","guard_weights","return_reach","return_planes","support_elbows","arm_poles","delivery_lean","carry_lean"]: print(key," ",r.get(key,"missing"))
		print("reconstrained ",Motion.constrain(r.duplicate(true))["wrists"])
		var gh=r["guard_homes"][i]+r["head"]-r["guard_reference"][i]
		var hc=Motion._self_clear_hand(r,gh,i)
		var ha=Motion._clear_arm(r,hc,r["arm_poles"][i],i)
		var reach=maxf(r["return_reach"][i],ha["end"].distance_to(shoulder))
		print("HOME raw ",gh," clear ",hc," arm ",ha," reach ",reach)
		var hh=Motion._head_clear_hand(r,gh,i,reach)
		print("HEAD bounded ",hh," torso ",Motion._torso_clearance(r,hh,0.143,i)," reach ",hh.distance_to(shoulder)," delta ",hh.distance_to(r["head"]))
		var bc=Motion._self_clear_hand(r,gh,i,reach)
		print("BOUNDED clear ",bc," arm ",Motion._clear_arm(r,bc,r["arm_poles"][i],i,reach))
		var arm=Motion.joint(shoulder,hand,pole,Motion.UPPER_ARM,Motion.FOREARM)
		print("raw ",arm," gap ",Motion._arm_gap(r,arm,i)," final ",r["elbows"][i]," head ",r["head"])
		for n in range(-5,6):
			var angle=n*PI/24.0
			var candidate=Motion.joint(shoulder,hand,pole.rotated(axis,angle),Motion.UPPER_ARM,Motion.FOREARM)
			print("plane ",n," gap ",Motion._arm_gap(r,candidate,i)," elbow ",candidate["joint"])
	quit()
